/*
 * polar.js — Cartesian to polar conversion.
 *
 * This is the heart of the "browser does the work" decision. The ESP32 never
 * decodes a JPEG, PNG or GIF; it receives a fixed-size block of bytes that is
 * already indexed the way the rotor needs to read it.
 *
 * Output layout (angle-major, so the firmware reads one contiguous run per
 * column and can DMA it straight at the strip):
 *
 *   offset(a, r, c) = (a * LEDS_PER_ARM + r) * 3 + c
 *
 *     a = angular sector,  0 .. ANGULAR_STEPS-1, CCW from the +x axis
 *     r = radial index,    0 = hub, LEDS_PER_ARM-1 = tip
 *     c = colour channel,  0 = R, 1 = G, 2 = B
 *
 * The arms are 180 deg apart, so at rotor angle theta the firmware writes
 * sector a=theta to one arm and sector a=theta+180deg to the other. Both are
 * present in the buffer; no mirroring is needed on-device.
 */

import { HW, FRAME_BYTES, IMAGE_DEFAULTS } from './config.js';

/* .povf container ---------------------------------------------------------
 * A self-describing header so a file sitting on LittleFS can be validated
 * and played back without any side-channel metadata.
 *
 *   0  u32  magic 'POVF' (big-endian 0x504F5646)
 *   4  u8   version (1)
 *   5  u8   radial     (LEDs per arm)
 *   6  u16  angles     (angular sectors)
 *   8  u16  frames
 *  10  u8   fps
 *  11  u8   flags      (bit0: loop)
 *  12  u32  payload byte length
 *  16  ...  frames, each radial*angles*3 bytes
 */
export const POVF_VERSION = 1;
export const POVF_HEADER_BYTES = 16;
export const POVF_FLAG_LOOP = 0x01;

export function buildPovf(frames, { fps = HW.FPS_DEFAULT, loop = true } = {}) {
  const radial = HW.LEDS_PER_ARM;
  const angles = HW.ANGULAR_STEPS;
  const payload = frames.length * FRAME_BYTES;
  const out = new Uint8Array(POVF_HEADER_BYTES + payload);
  const view = new DataView(out.buffer);

  view.setUint32(0, 0x504f5646, false);
  view.setUint8(4, POVF_VERSION);
  view.setUint8(5, radial);
  view.setUint16(6, angles, false);
  view.setUint16(8, frames.length, false);
  view.setUint8(10, fps);
  view.setUint8(11, loop ? POVF_FLAG_LOOP : 0);
  view.setUint32(12, payload, false);

  frames.forEach((f, i) => out.set(f, POVF_HEADER_BYTES + i * FRAME_BYTES));
  return out;
}

export function parsePovfHeader(buf) {
  const view = new DataView(buf.buffer ?? buf, buf.byteOffset ?? 0);
  if (view.getUint32(0, false) !== 0x504f5646) throw new Error('not a .povf file');
  return {
    version: view.getUint8(4),
    radial: view.getUint8(5),
    angles: view.getUint16(6, false),
    frames: view.getUint16(8, false),
    fps: view.getUint8(10),
    loop: (view.getUint8(11) & POVF_FLAG_LOOP) !== 0,
    payloadBytes: view.getUint32(12, false),
  };
}

/* --- Source preparation --------------------------------------------------
 * Squares up an arbitrary image into an RGBA buffer we can sample from.
 *
 * We deliberately render at a multiple of the final diameter (default 4x =
 * 256px) and let the browser's own filtering do the heavy downscale. Sampling
 * a 4000px photo directly at 32 radial steps would alias badly — thin
 * features would flicker in and out between angular sectors.
 */
const SUPERSAMPLE = 4;

export function prepareSource(source, opts = {}) {
  const { fit, rotationDeg, mirror } = { ...IMAGE_DEFAULTS, ...opts };
  const size = HW.LEDS_PER_ARM * 2 * SUPERSAMPLE; // 256 for a 64px disc

  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = size;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, size, size);

  const sw = source.width;
  const sh = source.height;
  // 'cover' fills the square (crops the long edge); 'contain' fits it all in.
  const scale = fit === 'contain' ? Math.min(size / sw, size / sh) : Math.max(size / sw, size / sh);
  const dw = sw * scale;
  const dh = sh * scale;

  ctx.save();
  ctx.translate(size / 2, size / 2);
  if (rotationDeg) ctx.rotate((rotationDeg * Math.PI) / 180);
  if (mirror) ctx.scale(-1, 1);
  ctx.drawImage(source, -dw / 2, -dh / 2, dw, dh);
  ctx.restore();

  return ctx.getImageData(0, 0, size, size);
}

/* --- Gamma ---------------------------------------------------------------
 * Precomputed 256-entry LUT. Rebuilt only when gamma/brightness change,
 * which matters when converting 64 GIF frames back to back.
 */
let lutKey = '';
let lut = null;

function gammaLut(gamma, brightness) {
  const key = `${gamma}|${brightness}`;
  if (key === lutKey) return lut;
  const t = new Uint8Array(256);
  for (let i = 0; i < 256; i++) {
    t[i] = Math.round(Math.pow(i / 255, gamma) * brightness * 255);
  }
  lutKey = key;
  lut = t;
  return t;
}

/* --- The conversion ------------------------------------------------------ */

/**
 * Convert a prepared square ImageData into a polar frame buffer.
 * Bilinear sampling — the supersampled source means this is already
 * effectively area-averaged.
 */
export function toPolarFrame(imageData, opts = {}) {
  const { gamma, brightness } = { ...IMAGE_DEFAULTS, ...opts };
  const radial = HW.LEDS_PER_ARM;
  const angles = HW.ANGULAR_STEPS;
  const inner = HW.INNER_RADIUS_RATIO;

  const src = imageData.data;
  const size = imageData.width;
  const cx = (size - 1) / 2;
  const cy = (size - 1) / 2;
  const maxR = size / 2 - 0.5;

  const table = gammaLut(gamma, brightness);
  const out = new Uint8Array(FRAME_BYTES);

  for (let a = 0; a < angles; a++) {
    // Screen y grows downward; negate so sector 0 points right and sectors
    // advance counter-clockwise, matching the rotor's encoder convention.
    const theta = (2 * Math.PI * a) / angles;
    const dx = Math.cos(theta);
    const dy = -Math.sin(theta);
    const rowBase = a * radial * 3;

    for (let r = 0; r < radial; r++) {
      // LED centres sit at the midpoint of their radial cell.
      const frac = inner + (1 - inner) * ((r + 0.5) / radial);
      const px = cx + dx * frac * maxR;
      const py = cy + dy * frac * maxR;

      const x0 = Math.floor(px);
      const y0 = Math.floor(py);
      const fx = px - x0;
      const fy = py - y0;
      const x1 = Math.min(x0 + 1, size - 1);
      const y1 = Math.min(y0 + 1, size - 1);

      const i00 = (y0 * size + x0) * 4;
      const i10 = (y0 * size + x1) * 4;
      const i01 = (y1 * size + x0) * 4;
      const i11 = (y1 * size + x1) * 4;

      const w00 = (1 - fx) * (1 - fy);
      const w10 = fx * (1 - fy);
      const w01 = (1 - fx) * fy;
      const w11 = fx * fy;

      const o = rowBase + r * 3;
      for (let c = 0; c < 3; c++) {
        const v =
          src[i00 + c] * w00 + src[i10 + c] * w10 + src[i01 + c] * w01 + src[i11 + c] * w11;
        out[o + c] = table[v < 0 ? 0 : v > 255 ? 255 : Math.round(v)];
      }
    }
  }
  return out;
}

/**
 * How much of the source image survives the conversion. Purely informational —
 * used to warn the user when 'cover' is about to crop most of their photo.
 */
export function coverageReport(source, opts = {}) {
  const { fit } = { ...IMAGE_DEFAULTS, ...opts };
  const aspect = source.width / source.height;
  const skew = aspect > 1 ? aspect : 1 / aspect;
  // Fraction of the square that the inscribed circle occupies.
  const discOfSquare = Math.PI / 4;
  const visible = fit === 'contain' ? discOfSquare / skew : discOfSquare;
  return {
    fit,
    aspect,
    /* Rough fraction of the original image's pixels that end up on the disc. */
    visibleFraction: visible,
    cropsHeavily: fit === 'cover' && skew > 1.6,
  };
}
