/*
 * ui/status.js — read-only telemetry panel.
 *
 * Everything here is reported by the firmware; the UI computes nothing about
 * the machine's safety or health, it only presents it. The one derived value
 * is refresh rate, which is just measured RPM x arms / 60.
 */

import { HW } from '../config.js';
import { state, activeUnit } from '../state.js';
import { STATE_LABEL } from './control.js';

const el = {};

export function initStatus() {
  el.pill = document.getElementById('state-pill');
  el.detail = document.getElementById('state-detail');
  el.rpmActual = document.getElementById('rpm-actual');
  el.refresh = document.getElementById('refresh');
  el.rotorLink = document.getElementById('rotor-link');
  el.rotorRpm = document.getElementById('rotor-rpm');
  el.geometry = document.getElementById('spec-geometry');
  el.content = document.getElementById('spec-content');

  el.geometry.textContent =
    `${HW.LEDS_TOTAL} LEDs · ${HW.LEDS_PER_ARM} px radius · ${HW.ANGULAR_STEPS} steps`;
}

export function renderStatus() {
  const unit = activeUnit();
  const online = state.connection.online;

  el.pill.dataset.state = unit.state;
  el.pill.textContent = online ? (STATE_LABEL[unit.state] ?? unit.state) : 'Offline';

  el.detail.textContent = online
    ? unit.state === 'running' && unit.rpmActual
      ? `holding ${unit.rpmActual} rpm`
      : ''
    : state.connection.detail || 'Not connected to the fan';

  el.rpmActual.textContent = online && unit.rpmActual ? Math.round(unit.rpmActual) : '—';

  const hz = unit.rpmActual ? ((unit.rpmActual / 60) * HW.ARMS) : 0;
  el.refresh.textContent = online && hz ? hz.toFixed(1) : '—';

  // --- Rotor ---
  const rotor = unit.rotor;
  if (!online) {
    el.rotorLink.textContent = '—';
  } else if (!rotor.online) {
    el.rotorLink.textContent = 'Down';
  } else if (rotor.rssi != null) {
    el.rotorLink.textContent = `${rotor.rssi} dBm`;
  } else {
    el.rotorLink.textContent = 'Up';
  }

  /* The rotor's own Hall-measured speed, alongside the motor encoder's figure
   * in "Measured speed". They are two independent sensors on the same shaft,
   * so reading them together is a free health check: agreement means the sync
   * chain is sound, and a rotor figure at half the stator's means the Hall is
   * missing every other pulse.
   *
   * Blanked when *either* link is down — if we cannot reach the C6, whatever
   * the rotor last reported is stale and must not be shown as live. Zero is a
   * genuine reading (the arm is stopped) and is shown as 0, not as blank. */
  const rotorRpm = online && rotor.online ? rotor.rpm : null;
  el.rotorRpm.textContent = rotorRpm == null ? '—' : Math.round(rotorRpm);

  el.content.textContent = unit.content?.name || 'Nothing loaded';
}
