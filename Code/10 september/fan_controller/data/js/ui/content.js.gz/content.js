/*
 * ui/content.js — library browsing, upload, conversion and preview.
 *
 * The upload flow has three stages, and the user sees all three because on a
 * microcontroller AP they take noticeably different amounts of time:
 *
 *   1. Converting  — in-browser, fast (tens of ms per frame).
 *   2. Uploading   — browser to ESP32-C6 over WiFi. Seconds.
 *   3. Publishing  — C6 to rotor over ESP-NOW. This is the slow one:
 *                    ~17 KB per frame at a realistic few hundred kbps, so a
 *                    long animation can take tens of seconds. The device
 *                    reports progress on the event stream.
 */

import { HW, FRAME_BYTES, IMAGE_DEFAULTS } from '../config.js';
import { api, upload } from '../api.js';
import { decodeGif, planPlayback } from '../gif.js';
import { prepareSource, toPolarFrame, buildPovf, coverageReport } from '../polar.js';
import { renderFrame, playFrames, drawGuides } from '../preview.js';
import { state, activeUnit, update, toast } from '../state.js';

const el = {};

/* Source material for the pending upload, kept decoded so that changing
 * fit/rotation only re-runs the polar conversion, not the decode. */
let pending = null; // { name, sources: (ImageBitmap|ImageData)[], fps, plan }
let converted = null; // Uint8Array[]
let player = null;
let uploadAbort = null;
let renderedLibraryKey = '';
let sending = false;

/* Thumbnails for user uploads live in localStorage, not on the device — the
 * ESP32 has better uses for its flash than 64x64 PNGs, and the browser that
 * did the upload is usually the one browsing the library. Presets ship their
 * thumbnails inside the web bundle instead. */
const THUMB_PREFIX = 'fan.thumb.';

function saveThumb(id, dataUrl) {
  try {
    localStorage.setItem(THUMB_PREFIX + id, dataUrl);
  } catch {
    /* quota full or private mode — thumbnails are cosmetic, carry on */
  }
}
function loadThumb(id) {
  try {
    return localStorage.getItem(THUMB_PREFIX + id);
  } catch {
    return null;
  }
}
function dropThumb(id) {
  try {
    localStorage.removeItem(THUMB_PREFIX + id);
  } catch {
    /* ignore */
  }
}

export function initContent() {
  el.preview = document.getElementById('preview');
  el.guides = document.getElementById('preview-guides');
  el.thumb = document.getElementById('preview-thumb');
  el.previewEmpty = document.getElementById('preview-empty');
  el.previewCaption = document.getElementById('preview-caption');

  el.tabLibrary = document.getElementById('tab-library');
  el.tabUpload = document.getElementById('tab-upload');
  el.paneLibrary = document.getElementById('pane-library');
  el.paneUpload = document.getElementById('pane-upload');

  el.library = document.getElementById('library');
  el.libraryEmpty = document.getElementById('library-empty');

  el.drop = document.getElementById('drop');
  el.file = document.getElementById('file');
  el.opts = document.getElementById('opts');
  el.fit = document.getElementById('fit');
  el.rotate = document.getElementById('rotate');
  el.mirror = document.getElementById('mirror');
  el.note = document.getElementById('convert-note');
  el.progress = document.getElementById('progress');
  el.progressStage = document.getElementById('progress-stage');
  el.progressPct = document.getElementById('progress-pct');
  el.progressFill = document.getElementById('progress-fill');
  el.actions = document.getElementById('upload-actions');
  el.send = document.getElementById('send');
  el.cancel = document.getElementById('cancel');

  /* Built here rather than in index.html so this guard is self-contained: it
   * reuses the existing .field-note styling and needs no markup or CSS change.
   * Sits directly above the Send button, which is what it is explaining. */
  el.blocked = document.createElement('p');
  el.blocked.className = 'field-note';
  el.blocked.dataset.kind = 'warn';
  el.blocked.hidden = true;
  el.blocked.textContent =
    'Stop the fan before sending. Saving an image to the fan\u2019s memory ' +
    'briefly interrupts the motor control loop, which is not safe while the ' +
    'arm is turning \u2014 so this is disabled until it has come to a stop. ' +
    'You can still prepare your image in the meantime.';
  el.actions.parentNode.insertBefore(el.blocked, el.actions);

  el.fit.value = IMAGE_DEFAULTS.fit;
  drawGuides(el.guides);

  el.tabLibrary.addEventListener('click', () => showTab('library'));
  el.tabUpload.addEventListener('click', () => showTab('upload'));

  el.drop.addEventListener('click', () => el.file.click());
  el.drop.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      el.file.click();
    }
  });
  el.file.addEventListener('change', () => {
    if (el.file.files?.[0]) handleFile(el.file.files[0]);
    el.file.value = '';
  });

  ['dragenter', 'dragover'].forEach((evt) =>
    el.drop.addEventListener(evt, (e) => {
      e.preventDefault();
      el.drop.dataset.over = 'true';
    })
  );
  ['dragleave', 'drop'].forEach((evt) =>
    el.drop.addEventListener(evt, (e) => {
      e.preventDefault();
      el.drop.dataset.over = 'false';
    })
  );
  el.drop.addEventListener('drop', (e) => {
    const file = e.dataTransfer?.files?.[0];
    if (file) handleFile(file);
  });
  // Stop a stray drop elsewhere on the page from navigating away from the app.
  window.addEventListener('dragover', (e) => e.preventDefault());
  window.addEventListener('drop', (e) => e.preventDefault());

  [el.fit, el.rotate, el.mirror].forEach((input) =>
    input.addEventListener('change', () => {
      if (pending) reconvert();
    })
  );

  el.send.addEventListener('click', sendToFan);
  el.cancel.addEventListener('click', clearPending);
}

/* Mirrors the firmware's own test in handleUploadBody(): not powered, and the
 * arm actually stationary. rpmActual is the device's displacement-over-250 ms
 * figure, so it reads a true zero at standstill -- 5 rpm is RPM_STOPPED in
 * fan_controller/src/config.h.
 *
 * The device refuses regardless of what this returns; the point of checking
 * here is to say so BEFORE the user has converted an image and watched it
 * upload, not after. */
function uploadAllowed() {
  const unit = activeUnit();
  return !unit.power && Math.abs(unit.rpmActual || 0) <= 5;
}

function updateSendGate() {
  const allowed = uploadAllowed();
  el.send.disabled = sending || !allowed;
  // Only nag when there is actually something waiting to be sent.
  el.blocked.hidden = allowed || !pending;
}

function showTab(which) {
  const isUpload = which === 'upload';
  el.tabUpload.setAttribute('aria-selected', String(isUpload));
  el.tabLibrary.setAttribute('aria-selected', String(!isUpload));
  el.paneUpload.hidden = !isUpload;
  el.paneLibrary.hidden = isUpload;
}

/* --- Preview ------------------------------------------------------------- */

function stopPlayer() {
  player?.stop();
  player = null;
}

/* The live canvas takes over the preview while an upload is being composed;
 * otherwise the stage shows a still thumbnail of whatever the fan is
 * currently displaying. */
function showPreview(frames, fps) {
  stopPlayer();
  el.previewEmpty.hidden = true;
  el.thumb.hidden = true;
  el.preview.hidden = false;
  player = playFrames(el.preview, frames, fps);
}

function clearPreview() {
  stopPlayer();
  el.preview.getContext('2d').clearRect(0, 0, el.preview.width, el.preview.height);
  el.preview.hidden = true;
  renderedThumbId = null; // force the current-content thumbnail to redraw
}

/** Show the thumbnail for whatever the device says it's currently displaying. */
let renderedThumbId = null;

function renderCurrentThumb() {
  if (pending) return; // a live preview owns the stage

  const item = activeUnit().content;
  const id = item?.id ?? null;
  if (id === renderedThumbId) return;
  renderedThumbId = id;

  if (!id) {
    el.thumb.hidden = true;
    el.previewEmpty.hidden = false;
    return;
  }

  const listed = state.library.find((i) => i.id === id);
  const src =
    listed?.kind === 'preset'
      ? `presets/${encodeURIComponent(id)}.png`
      : loadThumb(id);

  if (!src) {
    // Uploaded from a different phone, so this browser has no thumbnail for
    // it. Say what's playing rather than showing a blank disc.
    el.thumb.hidden = true;
    el.previewEmpty.textContent = `Showing “${item.name}”`;
    el.previewEmpty.hidden = false;
    return;
  }

  el.thumb.src = src;
  el.thumb.hidden = false;
  el.previewEmpty.hidden = true;
}

/* --- File handling ------------------------------------------------------- */

async function handleFile(file) {
  if (!HW.ACCEPTED_TYPES.includes(file.type)) {
    toast('Only JPEG, PNG and GIF images can be displayed', 'error');
    return;
  }
  if (file.size > HW.MAX_SOURCE_BYTES) {
    const mb = (HW.MAX_SOURCE_BYTES / 1024 / 1024).toFixed(0);
    toast(`That file is over ${mb} MB — try a smaller one`, 'error');
    return;
  }

  showTab('upload');
  setStage('converting', 0, 'Reading image…');

  try {
    const name = file.name.replace(/\.[^.]+$/, '').slice(0, 24) || 'Untitled';

    if (file.type === 'image/gif') {
      const buf = new Uint8Array(await file.arrayBuffer());
      const gif = decodeGif(buf);
      const plan = planPlayback(gif.frames, {
        targetFps: HW.FPS_DEFAULT,
        maxFrames: HW.MAX_FRAMES,
      });
      pending = {
        name,
        sources: plan.picks.map((i) => gif.frames[i].data),
        fps: plan.fps,
        plan,
        animated: gif.frames.length > 1,
      };
    } else {
      const bitmap = await createImageBitmap(file);
      pending = { name, sources: [bitmap], fps: 1, plan: null, animated: false };
    }

    await reconvert();
    el.opts.hidden = false;
    el.actions.hidden = false;
    updateSendGate();
  } catch (err) {
    console.error(err);
    pending = null;
    hideProgress();
    toast(err.message || 'Could not read that image', 'error');
  }
}

function currentOptions() {
  return {
    fit: el.fit.value,
    rotationDeg: Number(el.rotate.value),
    mirror: el.mirror.checked,
    gamma: IMAGE_DEFAULTS.gamma,
    brightness: IMAGE_DEFAULTS.brightness,
  };
}

async function reconvert() {
  if (!pending) return;
  const opts = currentOptions();
  const frames = [];

  setStage('converting', 0, 'Converting to LED data…');

  for (let i = 0; i < pending.sources.length; i++) {
    let source = pending.sources[i];
    // ImageData can't be drawn onto a canvas directly; bitmaps can.
    if (source instanceof ImageData) source = await createImageBitmap(source);
    frames.push(toPolarFrame(prepareSource(source, opts), opts));

    if (pending.sources.length > 4) {
      setStage('converting', (i + 1) / pending.sources.length, 'Converting frames…');
      // Yield so the progress bar actually paints on a long animation.
      if (i % 4 === 3) await new Promise((r) => setTimeout(r, 0));
    }
  }

  converted = frames;
  hideProgress();
  showPreview(frames, pending.fps);
  describePending();
}

function describePending() {
  const p = pending;
  if (!p) return;

  const bytes = converted.length * FRAME_BYTES;
  const notes = [];

  if (p.plan?.downsampled) {
    notes.push(
      `Original runs at ${p.plan.sourceFps} fps; the fan can hold ${p.fps} fps, so frames were resampled.`
    );
  }
  if (p.plan?.truncated) {
    notes.push(`Trimmed to ${HW.MAX_FRAMES} frames to fit device memory.`);
  }

  const source = p.sources[0];
  const cover = coverageReport(
    { width: source.width, height: source.height },
    currentOptions()
  );
  if (cover.cropsHeavily) {
    notes.push('This image is quite wide — the edges are being cropped. Try "Fit it all in".');
  }

  if (notes.length) {
    el.note.hidden = false;
    el.note.dataset.kind = 'warn';
    el.note.textContent = notes.join(' ');
  } else {
    el.note.hidden = false;
    el.note.dataset.kind = 'info';
    el.note.textContent = p.animated
      ? `${converted.length} frames at ${p.fps} fps · ${formatBytes(bytes)} to send.`
      : `Single image · ${formatBytes(bytes)} to send.`;
  }

  el.previewCaption.textContent = p.animated
    ? `Preview at ${p.fps} fps — exactly what the LEDs will paint.`
    : 'Preview shows exactly what the LEDs will paint.';
}

function formatBytes(n) {
  return n >= 1024 * 1024 ? `${(n / 1024 / 1024).toFixed(1)} MB` : `${Math.round(n / 1024)} KB`;
}

/**
 * Tear down the pending upload UI.
 * `keepProgress` is set once the file has reached the C6 but is still being
 * pushed to the rotor — that stage outlives the editing controls and has to
 * stay on screen.
 */
function clearPending({ keepProgress = false } = {}) {
  uploadAbort?.abort();
  uploadAbort = null;
  pending = null;
  converted = null;
  el.opts.hidden = true;
  el.actions.hidden = true;
  el.note.hidden = true;
  if (!keepProgress) hideProgress();
  updateSendGate();
  clearPreview();
  el.previewEmpty.textContent = 'Pick a preset or drop an image';
  el.previewCaption.textContent = 'Preview shows exactly what the LEDs will paint.';
  renderCurrentThumb();
}

/* --- Progress ------------------------------------------------------------ */

const STAGE_TEXT = {
  converting: 'Converting',
  uploading: 'Sending to fan',
  publishing: 'Loading onto rotor',
};

function setStage(stage, progress, message) {
  el.progress.hidden = false;
  el.progressStage.textContent = message || STAGE_TEXT[stage] || 'Working…';
  el.progressPct.textContent = `${Math.round(progress * 100)}%`;
  el.progressFill.style.width = `${Math.round(progress * 100)}%`;
  update((s) => {
    s.upload.busy = true;
    s.upload.stage = stage;
    s.upload.progress = progress;
  });
}

function hideProgress() {
  el.progress.hidden = true;
  update((s) => {
    s.upload.busy = false;
    s.upload.stage = null;
    s.upload.progress = 0;
  });
}

/* If the firmware never reports rotor progress — because it doesn't implement
 * the event, or the rotor dropped off — the publishing bar would otherwise sit
 * there forever. Give up quietly after a spell with no events. */
let publishWatchdog = null;

function armPublishWatchdog() {
  clearTimeout(publishWatchdog);
  publishWatchdog = setTimeout(() => {
    if (state.upload.stage === 'publishing') hideProgress();
  }, 10000);
}

/** Called from app.js when the device reports ESP-NOW push progress. */
export function onRotorProgress({ progress = 0, done = false }) {
  if (state.upload.stage !== 'publishing') return;
  if (done) {
    clearTimeout(publishWatchdog);
    hideProgress();
    return;
  }
  setStage('publishing', progress);
  armPublishWatchdog();
}

/* --- Sending ------------------------------------------------------------- */

async function sendToFan() {
  if (!converted || !pending) return;

  /* Re-checked at the moment of sending, not just when the button was last
   * painted: the fan could have been started from another phone in between. */
  if (!uploadAllowed()) {
    toast('Stop the fan before sending an image to it', 'error');
    updateSendGate();
    return;
  }

  sending = true;
  updateSendGate();
  el.cancel.textContent = 'Cancel upload';

  const povf = buildPovf(converted, { fps: pending.fps, loop: true });
  uploadAbort = new AbortController();

  try {
    setStage('uploading', 0);
    const result = await upload(pending.name, povf, {
      signal: uploadAbort.signal,
      onProgress: (p) => setStage('uploading', p),
    });

    if (result?.id) {
      saveThumb(result.id, thumbnailDataUrl(converted[0]));
    }

    // The C6 has the file now, but the rotor doesn't. That push is the slow
    // part, so the progress bar stays up and switches to reporting it — the
    // editing controls go away, the progress does not.
    setStage('publishing', 0);
    armPublishWatchdog();

    toast('Sent — loading onto the rotor', 'success');
    await refreshLibrary();
    clearPending({ keepProgress: true });
    showTab('library');
  } catch (err) {
    hideProgress();
    toast(err.message, 'error');
  } finally {
    sending = false;
    updateSendGate();
    el.cancel.textContent = 'Cancel';
    uploadAbort = null;
  }
}

/** Render a frame to a small PNG data URL for the library grid. */
function thumbnailDataUrl(frame) {
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  renderFrame(c, frame);
  return c.toDataURL('image/png');
}

/* --- Library ------------------------------------------------------------- */

export async function refreshLibrary() {
  try {
    const items = await api.library();
    update((s) => {
      s.library = Array.isArray(items) ? items : items.items || [];
    });
  } catch (err) {
    // Non-fatal: the control panel still works without a library listing.
    console.warn('library refresh failed:', err.message);
  }
}

async function selectItem(item) {
  try {
    await api.select(item.id);
    update((s) => {
      activeUnit().content = { id: item.id, name: item.name };
    });
    // Switching content means re-sending every frame to the rotor, so a long
    // animation takes just as long here as it did on upload. Show it.
    if (item.frames > 1 || (item.bytes ?? 0) > FRAME_BYTES) {
      setStage('publishing', 0);
      armPublishWatchdog();
    }
    toast(`Showing “${item.name}”`, 'success');
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function deleteItem(item) {
  if (!confirm(`Delete "${item.name}" from the fan?`)) return;
  try {
    await api.remove(item.id);
    dropThumb(item.id);
    toast('Deleted', 'info');
    await refreshLibrary();
  } catch (err) {
    toast(err.message, 'error');
  }
}

export function renderContent() {
  const unit = activeUnit();
  const items = state.library;
  const currentId = unit.content?.id ?? null;

  renderCurrentThumb();
  // Runs on every status event, so stopping the fan re-enables Send by itself.
  updateSendGate();

  // Rebuilding the grid on every status tick would kill focus and hover, so
  // only touch the DOM when the listing or the selection actually changed.
  const key = items.map((i) => `${i.id}:${i.name}`).join('|') + `#${currentId}`;
  if (key === renderedLibraryKey) return;
  renderedLibraryKey = key;

  el.library.textContent = '';
  el.libraryEmpty.hidden = items.length > 0;

  for (const item of items) {
    const card = document.createElement('button');
    card.type = 'button';
    card.className = 'card';
    card.setAttribute('aria-current', String(item.id === currentId));
    card.addEventListener('click', () => selectItem(item));

    const thumb = document.createElement('img');
    thumb.className = 'card-thumb';
    thumb.alt = '';
    thumb.loading = 'lazy';
    // Presets ship a thumbnail in the web bundle; user uploads get one from
    // localStorage, saved by whichever browser did the upload.
    thumb.src =
      item.kind === 'preset'
        ? `presets/${encodeURIComponent(item.id)}.png`
        : loadThumb(item.id) || TRANSPARENT_PIXEL;
    thumb.onerror = () => {
      thumb.src = TRANSPARENT_PIXEL;
    };
    card.appendChild(thumb);

    const name = document.createElement('span');
    name.className = 'card-name';
    name.textContent = item.name;
    card.appendChild(name);

    if (item.frames > 1) {
      const badge = document.createElement('span');
      badge.className = 'card-badge';
      badge.textContent = 'anim';
      card.appendChild(badge);
    }

    if (item.kind !== 'preset') {
      const del = document.createElement('span');
      del.className = 'card-del';
      del.setAttribute('role', 'button');
      del.setAttribute('tabindex', '0');
      del.setAttribute('aria-label', `Delete ${item.name}`);
      del.textContent = '×';
      const remove = (e) => {
        e.stopPropagation();
        deleteItem(item);
      };
      del.addEventListener('click', remove);
      del.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') remove(e);
      });
      card.appendChild(del);
    }

    el.library.appendChild(card);
  }
}

const TRANSPARENT_PIXEL =
  'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
