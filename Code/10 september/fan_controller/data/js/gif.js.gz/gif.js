/*
 * gif.js — minimal animated-GIF decoder (GIF87a / GIF89a).
 *
 * Why hand-rolled instead of using the browser?
 *
 *   - An <img> tag animates a GIF but gives no way to step frames, so you
 *     can't capture them to a canvas reliably.
 *   - WebCodecs' ImageDecoder does expose frames, but the WebCodecs
 *     interfaces are [SecureContext]. The fan serves the page over plain
 *     HTTP from an ESP32 access point, which is not a secure context, so
 *     the API simply isn't there.
 *
 * So we parse the container and inflate the LZW streams ourselves. This
 * handles the parts of the spec that real-world GIFs actually use: global
 * and local colour tables, interlacing, transparency, and all four disposal
 * methods.
 */

const DISPOSAL_NONE = 0;
const DISPOSAL_KEEP = 1;
const DISPOSAL_BACKGROUND = 2;
const DISPOSAL_PREVIOUS = 3;

class Reader {
  constructor(bytes) {
    this.b = bytes;
    this.p = 0;
  }
  u8() {
    return this.b[this.p++];
  }
  u16() {
    const v = this.b[this.p] | (this.b[this.p + 1] << 8); // GIF is little-endian
    this.p += 2;
    return v;
  }
  bytes(n) {
    const v = this.b.subarray(this.p, this.p + n);
    this.p += n;
    return v;
  }
  str(n) {
    return String.fromCharCode(...this.bytes(n));
  }
  /* Sub-blocks are length-prefixed chunks terminated by a zero length. */
  subBlocks() {
    const parts = [];
    let total = 0;
    for (;;) {
      const len = this.u8();
      if (!len) break;
      const chunk = this.bytes(len);
      parts.push(chunk);
      total += len;
    }
    const out = new Uint8Array(total);
    let o = 0;
    for (const part of parts) {
      out.set(part, o);
      o += part.length;
    }
    return out;
  }
  skipSubBlocks() {
    for (;;) {
      const len = this.u8();
      if (!len) break;
      this.p += len;
    }
  }
}

function colorTable(reader, entries) {
  const t = new Uint8Array(entries * 3);
  t.set(reader.bytes(entries * 3));
  return t;
}

/*
 * LZW decompression, GIF variant. Codes are packed LSB-first and the code
 * width grows as the dictionary fills. Two reserved codes sit just above the
 * root entries: CLEAR resets the dictionary, END terminates the stream.
 */
function lzwDecode(minCodeSize, data, pixelCount) {
  const out = new Uint8Array(pixelCount);
  const clearCode = 1 << minCodeSize;
  const endCode = clearCode + 1;

  // Dictionary as parallel arrays: each entry is a prefix code plus one byte.
  // Walking the prefix chain backwards avoids allocating an array per entry.
  const maxEntries = 4096;
  const prefix = new Int16Array(maxEntries);
  const suffix = new Uint8Array(maxEntries);

  for (let i = 0; i < clearCode; i++) {
    prefix[i] = -1;
    suffix[i] = i;
  }

  let codeSize = minCodeSize + 1;
  let next = endCode + 1;
  let prev = -1;

  let bitBuf = 0;
  let bitCount = 0;
  let pos = 0;
  let outPos = 0;
  const stack = new Uint8Array(maxEntries);

  while (outPos < pixelCount) {
    while (bitCount < codeSize) {
      if (pos >= data.length) return out; // truncated stream — keep what we have
      bitBuf |= data[pos++] << bitCount;
      bitCount += 8;
    }
    const code = bitBuf & ((1 << codeSize) - 1);
    bitBuf >>= codeSize;
    bitCount -= codeSize;

    if (code === clearCode) {
      codeSize = minCodeSize + 1;
      next = endCode + 1;
      prev = -1;
      continue;
    }
    if (code === endCode) break;

    // Resolve the code to a string. If it isn't in the dictionary yet this is
    // the KwKwK case: the encoder used a code it was defining on the same
    // step, which can only ever mean prev's string plus prev's first byte.
    const known = code < next;
    if (!known && prev < 0) break; // corrupt stream
    const walkFrom = known ? code : prev;

    // Unwind the prefix chain onto the stack; this yields bytes in reverse.
    let sp = 0;
    let c = walkFrom;
    while (c >= 0) {
      stack[sp++] = suffix[c];
      c = prefix[c];
    }
    const firstByte = stack[sp - 1];

    // Emit forwards, then append the repeated first byte for KwKwK.
    for (let i = sp - 1; i >= 0 && outPos < pixelCount; i--) out[outPos++] = stack[i];
    if (!known && outPos < pixelCount) out[outPos++] = firstByte;

    // Every code after the first extends the previous string by one byte.
    if (prev >= 0 && next < maxEntries) {
      prefix[next] = prev;
      suffix[next] = firstByte;
      next++;
      if (next === 1 << codeSize && codeSize < 12) codeSize++;
    }
    prev = code;
  }
  return out;
}

/* Interlaced GIFs store rows in four passes. */
function deinterlace(indices, width, height) {
  const out = new Uint8Array(indices.length);
  const passes = [
    [0, 8],
    [4, 8],
    [2, 4],
    [1, 2],
  ];
  let src = 0;
  for (const [start, step] of passes) {
    for (let row = start; row < height; row += step) {
      out.set(indices.subarray(src * width, (src + 1) * width), row * width);
      src++;
    }
  }
  return out;
}

/**
 * Decode a GIF into fully-composited RGBA frames.
 *
 * @param {ArrayBuffer|Uint8Array} buffer
 * @returns {{width:number, height:number, frames:Array<{data:ImageData, delayMs:number}>}}
 */
export function decodeGif(buffer) {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  const r = new Reader(bytes);

  const sig = r.str(6);
  if (sig !== 'GIF87a' && sig !== 'GIF89a') throw new Error('Not a GIF file');

  const width = r.u16();
  const height = r.u16();
  const packed = r.u8();
  r.u8(); // background colour index — unused, we composite onto transparent
  r.u8(); // pixel aspect ratio

  let globalTable = null;
  if (packed & 0x80) globalTable = colorTable(r, 2 << (packed & 0x07));

  // Persistent canvas that frames are composited onto.
  const canvas = new Uint8ClampedArray(width * height * 4);
  let saved = null;

  const frames = [];
  let delayMs = 100;
  let disposal = DISPOSAL_NONE;
  let transparentIndex = -1;

  parse: for (;;) {
    if (r.p >= bytes.length) break;
    const block = r.u8();

    switch (block) {
      case 0x21: {
        // Extension
        const label = r.u8();
        if (label === 0xf9) {
          r.u8(); // block size, always 4
          const flags = r.u8();
          disposal = (flags >> 2) & 0x07;
          const hasTransparency = (flags & 0x01) !== 0;
          const delayCs = r.u16();
          const tIdx = r.u8();
          transparentIndex = hasTransparency ? tIdx : -1;
          r.u8(); // terminator
          // Browsers clamp 0 and 1 centisecond delays to 100ms; match that so
          // our frame-rate estimate agrees with what the user saw in preview.
          delayMs = delayCs <= 1 ? 100 : delayCs * 10;
        } else {
          r.skipSubBlocks();
        }
        break;
      }

      case 0x2c: {
        // Image descriptor
        const left = r.u16();
        const top = r.u16();
        const fw = r.u16();
        const fh = r.u16();
        const flags = r.u8();
        const interlaced = (flags & 0x40) !== 0;
        const table = flags & 0x80 ? colorTable(r, 2 << (flags & 0x07)) : globalTable;
        if (!table) throw new Error('GIF frame has no colour table');

        const minCodeSize = r.u8();
        const data = r.subBlocks();
        let indices = lzwDecode(minCodeSize, data, fw * fh);
        if (interlaced) indices = deinterlace(indices, fw, fh);

        // Snapshot before drawing, for DISPOSAL_PREVIOUS.
        if (disposal === DISPOSAL_PREVIOUS) saved = canvas.slice();

        for (let y = 0; y < fh; y++) {
          const cy = top + y;
          if (cy < 0 || cy >= height) continue;
          for (let x = 0; x < fw; x++) {
            const cx = left + x;
            if (cx < 0 || cx >= width) continue;
            const idx = indices[y * fw + x];
            if (idx === transparentIndex) continue; // leave what's underneath
            const s = idx * 3;
            const d = (cy * width + cx) * 4;
            canvas[d] = table[s];
            canvas[d + 1] = table[s + 1];
            canvas[d + 2] = table[s + 2];
            canvas[d + 3] = 255;
          }
        }

        frames.push({
          data: new ImageData(new Uint8ClampedArray(canvas), width, height),
          delayMs,
        });

        // Apply disposal ready for the next frame.
        if (disposal === DISPOSAL_BACKGROUND) {
          for (let y = top; y < top + fh && y < height; y++) {
            if (y < 0) continue;
            const rowStart = (y * width + Math.max(left, 0)) * 4;
            const rowEnd = (y * width + Math.min(left + fw, width)) * 4;
            canvas.fill(0, rowStart, rowEnd);
          }
        } else if (disposal === DISPOSAL_PREVIOUS && saved) {
          canvas.set(saved);
        }

        // Graphic control settings only apply to the frame that follows them.
        disposal = DISPOSAL_NONE;
        transparentIndex = -1;
        break;
      }

      case 0x3b: // trailer
        break parse;

      case 0x00: // stray padding, seen in the wild
        break;

      default:
        // Unknown block — we can't know its length, so stop rather than
        // walk off into garbage.
        break parse;
    }
  }

  if (!frames.length) throw new Error('GIF contained no frames');
  return { width, height, frames };
}

/**
 * Pick a playback rate the fan can actually sustain, and work out which
 * source frames to keep.
 *
 * The display refreshes at 2 x RPM/60 (two arms), which caps out around
 * 23 Hz, and the spec targets 12 fps with a 10 fps floor. Most GIFs are
 * authored faster than that, so we resample onto a uniform timeline rather
 * than dropping frames arbitrarily.
 */
export function planPlayback(frames, { targetFps, maxFrames }) {
  const totalMs = frames.reduce((sum, f) => sum + f.delayMs, 0);
  const sourceFps = totalMs > 0 ? (frames.length * 1000) / totalMs : targetFps;

  let fps = Math.min(targetFps, Math.max(1, Math.round(sourceFps)));
  let count = Math.max(1, Math.round((totalMs / 1000) * fps));

  if (count > maxFrames) {
    // Too long to fit in device memory: keep the duration, drop the rate.
    count = maxFrames;
    fps = Math.max(1, Math.round(count / (totalMs / 1000)));
  }

  // Nearest-neighbour resample onto an even timeline.
  const cumulative = [];
  let acc = 0;
  for (const f of frames) {
    cumulative.push(acc);
    acc += f.delayMs;
  }
  const stepMs = totalMs / count;
  const picks = [];
  for (let i = 0; i < count; i++) {
    const t = (i + 0.5) * stepMs;
    let best = 0;
    for (let j = 0; j < cumulative.length; j++) {
      if (cumulative[j] <= t) best = j;
      else break;
    }
    picks.push(best);
  }

  return {
    fps,
    picks,
    sourceFps: Math.round(sourceFps * 10) / 10,
    sourceFrames: frames.length,
    durationMs: totalMs,
    downsampled: picks.length < frames.length || fps < Math.round(sourceFps),
    truncated: count === maxFrames && (totalMs / 1000) * targetFps > maxFrames,
  };
}
