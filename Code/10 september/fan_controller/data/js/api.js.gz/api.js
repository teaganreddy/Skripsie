/*
 * api.js — the single surface the browser talks to.
 *
 * The page only ever speaks to the ESP32-C6. Whatever the C6 has to relay on
 * to the rotor (S3) over ESP-NOW is invisible from here — with one exception:
 * pushing content to the rotor is slow enough that it gets its own progress
 * stage, reported back over the event stream.
 *
 * Transport choice: REST for commands, Server-Sent Events for telemetry.
 * SSE rather than WebSockets because ESPAsyncWebServer ships AsyncEventSource
 * out of the box, it's one-directional (which is all telemetry needs), it
 * survives proxies, and it reconnects on its own. Commands are plain POSTs.
 *
 * >>> This contract is a PROPOSAL, not a settled spec. Firmware has to agree
 * >>> to it (or push back on it) — see API.md.
 */

import { apiBase, SSE_PATH, POLL_MS, RECONNECT_MS } from './config.js';

class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

async function request(path, { method = 'GET', body, timeout = 8000 } = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const res = await fetch(apiBase() + path, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal,
      cache: 'no-store',
    });
    if (!res.ok) {
      let detail = res.statusText;
      try {
        const j = await res.json();
        if (j && j.error) detail = j.error;
      } catch {
        /* non-JSON error body — keep the status text */
      }
      throw new ApiError(detail, res.status);
    }
    if (res.status === 204) return null;
    return await res.json();
  } catch (err) {
    if (err.name === 'AbortError') throw new ApiError('The fan did not respond', 0);
    if (err instanceof ApiError) throw err;
    throw new ApiError('Cannot reach the fan — check you are on its WiFi', 0);
  } finally {
    clearTimeout(timer);
  }
}

/* --- Commands ------------------------------------------------------------ */

export const api = {
  status: () => request('/api/status'),

  /** Spin up / spin down. The firmware ramps; it does not step. */
  setPower: (on) => request('/api/power', { method: 'POST', body: { on: !!on } }),

  /** Target RPM. Firmware clamps to its own safe range regardless. */
  setSpeed: (rpm) => request('/api/speed', { method: 'POST', body: { rpm: Math.round(rpm) } }),

  /** SK9822 global brightness, 0–31 (the chip's native 5-bit field). */
  setBrightness: (level) =>
    request('/api/brightness', { method: 'POST', body: { level: Math.round(level) } }),

  /** Immediate stop. Separate endpoint from setPower(false) so the firmware
   *  can treat it as a priority command and skip the ramp-down. */
  emergencyStop: () => request('/api/stop', { method: 'POST', timeout: 4000 }),

  /** Clear a latched fault once the cause has been dealt with. */
  clearFault: () => request('/api/fault/clear', { method: 'POST' }),

  library: () => request('/api/library'),

  select: (id) => request('/api/library/select', { method: 'POST', body: { id } }),

  remove: (id) => request(`/api/library/${encodeURIComponent(id)}`, { method: 'DELETE' }),
};

/* --- Upload --------------------------------------------------------------
 * XHR rather than fetch: fetch still has no upload-progress event in any
 * shipping browser, and over a microcontroller AP an upload can take tens of
 * seconds. A progress bar is not optional here.
 */
export function upload(name, povfBytes, { onProgress, signal } = {}) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `${apiBase()}/api/upload?name=${encodeURIComponent(name)}`);
    xhr.setRequestHeader('Content-Type', 'application/octet-stream');
    xhr.timeout = 120000;

    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable && onProgress) onProgress(e.loaded / e.total);
    };
    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          resolve(JSON.parse(xhr.responseText));
        } catch {
          resolve({});
        }
      } else {
        let msg = `Upload failed (${xhr.status})`;
        try {
          const j = JSON.parse(xhr.responseText);
          if (j.error) msg = j.error;
        } catch {
          /* keep the generic message */
        }
        reject(new ApiError(msg, xhr.status));
      }
    };
    xhr.onerror = () => reject(new ApiError('Connection lost during upload', 0));
    xhr.ontimeout = () => reject(new ApiError('Upload timed out', 0));
    xhr.onabort = () => reject(new ApiError('Upload cancelled', 0));

    if (signal) signal.addEventListener('abort', () => xhr.abort(), { once: true });

    xhr.send(povfBytes);
  });
}

/* --- Telemetry stream ----------------------------------------------------
 * Subscribes to SSE and falls back to polling whenever the stream is down,
 * so the UI keeps updating even if the device's event source is flaky or the
 * user is on a browser/proxy that mangles SSE.
 */
export function subscribe({ onStatus, onConnection, onRotorProgress }) {
  let source = null;
  let pollTimer = null;
  let reconnectTimer = null;
  let closed = false;
  let connected = null; // null = not yet determined
  let connectedDetail = '';

  function setConnected(value, detail = '') {
    // Compare the detail too: the first failure reports "event stream lost",
    // and the polling retry that follows has a better explanation. Without
    // this the UI would be stuck showing whichever arrived first.
    if (connected === value && connectedDetail === detail) return;
    connected = value;
    connectedDetail = detail;
    onConnection?.(value, detail);
  }

  async function pollOnce() {
    try {
      const status = await api.status();
      setConnected(true);
      onStatus?.(status);
    } catch (err) {
      setConnected(false, err.message);
    }
  }

  function startPolling() {
    if (pollTimer) return;
    pollOnce();
    pollTimer = setInterval(pollOnce, POLL_MS);
  }

  function stopPolling() {
    clearInterval(pollTimer);
    pollTimer = null;
  }

  function connect() {
    if (closed) return;
    try {
      source = new EventSource(apiBase() + SSE_PATH);
    } catch {
      startPolling();
      return;
    }

    source.onopen = () => {
      stopPolling();
      setConnected(true);
    };

    source.addEventListener('status', (e) => {
      try {
        onStatus?.(JSON.parse(e.data));
        setConnected(true);
      } catch {
        /* malformed frame — ignore this one, the next will be along shortly */
      }
    });

    // Emitted while the C6 is pushing frame data on to the rotor over
    // ESP-NOW, which is the slow half of publishing new content.
    source.addEventListener('rotor-progress', (e) => {
      try {
        onRotorProgress?.(JSON.parse(e.data));
      } catch {
        /* ignore */
      }
    });

    source.onerror = () => {
      source?.close();
      source = null;
      setConnected(false, 'Lost contact with the fan');
      startPolling(); // keep the UI alive while we retry
      clearTimeout(reconnectTimer);
      reconnectTimer = setTimeout(connect, RECONNECT_MS);
    };
  }

  connect();
  // Prime the UI immediately rather than waiting for the first pushed event.
  pollOnce();

  return function unsubscribe() {
    closed = true;
    source?.close();
    stopPolling();
    clearTimeout(reconnectTimer);
  };
}

export { ApiError };
