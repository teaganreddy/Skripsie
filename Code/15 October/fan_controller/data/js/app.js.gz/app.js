/*
 * app.js -- wiring.
 *
 * Subscribes to the device, folds telemetry into the store, and re-renders
 * the three panels whenever the store changes. No router, no virtual DOM:
 * one page, three panels, a handful of listeners.
 */

import { subscribe } from './api.js';
import { subscribeState, applyStatus, setConnection, state } from './state.js';
import { initControl, renderControl } from './ui/control.js';
import { initStatus, renderStatus } from './ui/status.js';
import { initContent, renderContent, refreshLibrary, onRotorProgress } from './ui/content.js';
import { initRail, renderRail } from './ui/rail.js';
import { initFans, renderFans } from './ui/fans.js';
import { initScenes, renderScenes } from './ui/scenes.js';
import { initDiagnostics, renderDiagnostics, setDiagnosticsVisible } from './ui/diagnostics.js';

const toastEl = document.getElementById('toast');

function renderToast() {
  const t = state.toast;
  if (!t) {
    toastEl.hidden = true;
    return;
  }
  toastEl.hidden = false;
  toastEl.dataset.kind = t.kind;
  toastEl.textContent = t.message;
}

/* Control / Scenes. Remembered per browser so a phone that lives on the
 * Scenes tab at a demo comes back to it. */
function initViews() {
  const layout = document.getElementById('layout');
  const tabs = {
    control: document.getElementById('view-control'),
    scenes: document.getElementById('view-scenes'),
    diagnostics: document.getElementById('view-diagnostics'),
  };
  const show = (view) => {
    layout.dataset.view = view;
    for (const [k, b] of Object.entries(tabs)) b.setAttribute('aria-selected', String(k === view));
    setDiagnosticsVisible(view === 'diagnostics');  // the log only polls while shown
    try { localStorage.setItem('view', view); } catch { /* private mode */ }
  };
  for (const [k, b] of Object.entries(tabs)) b.addEventListener('click', () => show(k));
  let saved = null;
  try { saved = localStorage.getItem('view'); } catch { /* ignore */ }
  show(saved in tabs ? saved : 'control');
}

function boot() {
  initControl();
  initStatus();
  initContent();
  initRail();
  initFans();
  initScenes();
  initDiagnostics();
  initViews();

  subscribeState(() => {
    renderFans();
    renderControl();
    renderStatus();
    renderRail();
    renderContent();
    renderScenes();
    renderDiagnostics();
    renderToast();
  });

  subscribe({
    onStatus: (payload) => applyStatus(payload),
    onConnection: (online, detail) => {
      setConnection(online, detail);
      // Re-pull the library on every reconnect: the device may have been
      // power-cycled, or another phone may have uploaded something.
      if (online) refreshLibrary();
    },
    onRotorProgress,
  });

  // The logo's arm spins while any fan is actually turning.
  const brandMark = document.getElementById('brand-mark');
  subscribeState(() => {
    const spinning = state.connection.online &&
      Object.values(state.units).some((u) => u.online && (u.power || u.state === 'running' ||
                                                         u.state === 'starting' || u.state === 'stopping'));
    brandMark.dataset.spinning = String(spinning);
  });

  // The connection pill starts as "Connecting…" rather than "Offline" so a
  // normal first load doesn't flash a scary red state.
  const label = document.getElementById('conn-label');
  const pill = document.getElementById('conn');
  subscribeState(() => {
    const online = state.connection.online;
    pill.dataset.online = String(online);
    label.textContent = online ? 'Connected' : state.connection.detail || 'Not connected';
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot, { once: true });
} else {
  boot();
}
