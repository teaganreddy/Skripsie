/*
 * scenes.js -- the two-fan shows on the Scenes tab.
 *
 * A scene is a rail mode plus one preset per fan. The presets are generated
 * by tools/make-presets.js (SCENES there) and their behaviour flags live in
 * the firmware's preset table (fan_controller/src/content.cpp). All three
 * lists name the same ids; keep them in step.
 *
 *   position  the rail parks both fans in the middle and they play in step:
 *             the master sends a loop pulse once per animation so the ball
 *             leaves one disc and arrives on the other on time.
 *   sweep     the rail glides side to side with the fans running; the
 *             content is drawn facing right and the rotors mirror it while
 *             the carriage moves left, so the fish swim the way they travel.
 *             Flappy is a sweep scene too, but its two files are one whole
 *             rail cycle each, and the master restarts them at the matching
 *             frame every time the carriage sets off.
 */

export const SCENES = [
  {
    id: 'pong',
    name: 'Pong',
    mode: 'position',
    left: 'pong-left',
    right: 'pong-right',
    blurb: 'A rally between the two fans. Each fan guards its own goal.',
  },
  {
    id: 'penalty',
    name: 'Penalty',
    mode: 'position',
    left: 'penalty-left',
    right: 'penalty-right',
    blurb: 'Kick from the left fan, goal and keeper on the right.',
  },
  {
    id: 'fish',
    name: 'Fish',
    mode: 'sweep',
    left: 'fish',
    right: 'fish',
    blurb: 'Fish swim with the rail and turn round at each end.',
  },
  {
    id: 'flappy',
    name: 'Flappy',
    mode: 'sweep',
    left: 'flappy-left',
    right: 'flappy-right',
    /* Drawn against this exact sweep: tools/make-presets.js reads sweepMms
     * from here, so change it only together with `npm run presets`. The
     * file is one whole rail cycle and must start with a leg from HOME. */
    sweepMms: 35,
    fromHome: true,
    blurb: 'A bird flies through the pipes, the length of the rail and back.',
  },
];

/** Preset ids that belong to a scene, hidden from the ordinary Library. */
export const SCENE_CONTENT_IDS = new Set(SCENES.flatMap((s) => [s.left, s.right]));
