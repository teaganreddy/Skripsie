/*
 * ui/diagnostics.js -- the serial monitor you cannot plug in.
 *
 * Nothing that spins can have USB attached, and the stators sit under the
 * arms, so this tab shows what the boards would otherwise print: the
 * bring-up numbers per fan, the angle calibration controls, and the network
 * log (/api/log) that the master collects from every board.
 *
 * The log polls only while the tab is visible; the numbers come from the
 * ordinary status feed.
 */

import { api } from '../api.js';
import { state, subscribeStatus, toast } from '../state.js';

const el = {};
const cal = {};
let visible = false;
let pollTimer = null;
let nextSeq = 0;
let bootId = null;  // the fan's per-boot log id; a change means it restarted
let lines = []; // { seq, t, tag, text }
const MAX_LINES = 400;

const ROWS = [
  ['State', (u) => (u.online ? u.state : 'offline')],
  ['Target rpm', (u) => u.rpmTarget],
  ['Ramp rpm', (u) => u.rpmCommand],  // left only: where the ramp is right now
  ['Motor rpm', (u) => u.rpmActual],
  ['Rotor rpm (Hall)', (u) => u.rotor.rpm],
  ['Columns / s', (u) => u.diag.columnsPerSec],
  ['Sync locked', (u) => yesNo(u.diag.syncLocked)],
  /* Turn the arm by hand: this must flip high -> low -> high as the sensor
   * passes the magnet. Stuck high = no magnet seen; stuck low = shorted. */
  ['Hall input', (u) => (u.diag.hall === null ? null : u.diag.hall ? 'high' : 'low')],
  ['Overruns', (u) => u.diag.overruns, (v) => v > 0],
  ['Rejected pulses', (u) => u.diag.rejected, (v) => v > 0],
  ['Holds image', (u) => yesNo(u.rotorHasContent)],
  ['Pushing', (u) => yesNo(u.pushing)],
  ['Showing', (u) => u.content?.id ?? '-'],
  ['FOC loop Hz', (u) => u.diag.focLoopHz],
  ['Worst gap ms', (u) => u.diag.focMaxGapMs, (v) => v > 5],
  ['Uq V', (u) => u.diag.voltageQ],
  ['Ripple rpm', (u) => u.diag.rpmRipple],
  ['Rotor RSSI', (u) => u.rotor.rssi],
  ['Fault', (u) => (u.fault ? `${u.fault.code}` : '-'), (v) => v !== '-'],
];

function yesNo(v) {
  return v === null || v === undefined ? null : v ? 'yes' : 'no';
}
function fmt(v) {
  if (v === null || v === undefined) return '-';
  if (typeof v === 'number') return Number.isInteger(v) ? String(v) : v.toFixed(2);
  return String(v);
}

function stamp(ms) {
  const s = Math.floor(ms / 1000);
  return `${String(Math.floor(s / 60)).padStart(3, ' ')}:${String(s % 60).padStart(2, '0')}`;
}

async function pollLog() {
  if (!visible || !state.connection.online) return;
  try {
    const r = await api.log(nextSeq);
    /* The fan restarted: its log numbering began again from 1. Keeping the
     * old, higher number skipped every new line (including the [BOOT] line
     * that says why it restarted) until the count caught up. Detected by the
     * per-boot id, or by `next` going backwards on firmware without one.
     * Start again from the beginning of the fan's log. */
    const restarted =
      r && ((typeof r.boot === 'number' && bootId !== null && r.boot !== bootId) ||
            (typeof r.next === 'number' && r.next < nextSeq));
    if (r && typeof r.boot === 'number') bootId = r.boot;
    if (restarted) {
      nextSeq = 0;
      lines.push({ seq: 0, t: 0, tag: 'site', text: '-- the fan restarted, its log starts again below --' });
      renderLog();
      return pollLog();
    }
    if (r && Array.isArray(r.lines)) {
      const atBottom = el.log.scrollTop + el.log.clientHeight >= el.log.scrollHeight - 8;
      let added = false;
      for (const l of r.lines) {
        if (l.seq < nextSeq) continue;
        lines.push(l);
        added = true;
      }
      if (typeof r.next === 'number') nextSeq = Math.max(nextSeq, r.next);
      if (lines.length > MAX_LINES) lines = lines.slice(-MAX_LINES);
      if (added) {
        renderLog();
        if (atBottom) el.log.scrollTop = el.log.scrollHeight;
      }
      el.note.textContent = `${lines.length} lines`;
    }
  } catch (err) {
    el.note.textContent = err.message;
  }
}

function renderLog() {
  el.log.textContent = '';
  for (const l of lines) {
    const t = document.createElement('span');
    t.className = 't';
    t.textContent = `${stamp(l.t)} `;
    const tag = document.createElement('span');
    tag.className = 'tag';
    tag.textContent = `[${l.tag}] `;
    el.log.append(t, tag, document.createTextNode(`${l.text}\n`));
  }
}

function download() {
  const text = lines.map((l) => `${stamp(l.t)} [${l.tag}] ${l.text}`).join('\n');
  const blob = new Blob([text + '\n'], { type: 'text/plain' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  const d = new Date();
  a.download = `fan-log-${d.toISOString().slice(0, 19).replace(/[T:]/g, '-')}.txt`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

/* ---------------- Record ----------------
 * One row per status packet from the fan (STATUS_EVENT_MS, 2 Hz), kept in
 * this page only and downloaded as CSV for graphs. Nothing is written to the
 * fan. Runs whichever tab is showing; stops if the page is closed.
 * time_s is when the packet ARRIVED in the browser, so it carries a few tens
 * of ms of network jitter. left_rpm_ramp is the firmware's ramp output (the
 * setpoint the speed loop is chasing at that instant); the right fan does not
 * report it. */
const REC_MAX_ROWS = 20000;  // about 2.8 hours at 2 Hz
const REC_COLUMNS = [
  'time_s',
  'left_state', 'left_rpm_target', 'left_rpm_ramp', 'left_rpm_stator', 'left_rpm_rotor',
  'left_voltage_q', 'left_ripple_rpm',
  'right_state', 'right_rpm_target', 'right_rpm_stator', 'right_rpm_rotor', 'right_voltage_q',
];
const rec = { on: false, t0: 0, rows: [] };

const cell = (v) => {
  if (v === null || v === undefined) return '';
  if (typeof v === 'number' && !Number.isInteger(v)) return v.toFixed(2);
  return String(v);
};

function recSample() {
  if (!rec.on) return;
  if (rec.rows.length >= REC_MAX_ROWS) {
    setRecording(false);
    toast('Recording stopped: the buffer is full. Download it, then clear.', 'error');
    return;
  }
  const L = state.units[1], R = state.units[2];
  const t = ((performance.now() - rec.t0) / 1000).toFixed(2);
  const left = L.online
    ? [L.state, L.rpmTarget, L.rpmCommand, L.rpmActual, L.rotor.rpm, L.diag.voltageQ, L.diag.rpmRipple]
    : ['offline', '', '', '', '', '', ''];
  const right = R.online
    ? [R.state, R.rpmTarget, R.rpmActual, R.rotor.rpm, R.diag.voltageQ]
    : ['offline', '', '', '', ''];
  rec.rows.push([t, ...left, ...right].map(cell).join(','));
  renderRec();
}

function setRecording(on) {
  rec.on = on;
  if (on && rec.rows.length === 0) rec.t0 = performance.now();
  renderRec();
}

function renderRec() {
  const n = rec.rows.length;
  const secs = n ? Math.round(parseFloat(rec.rows[n - 1]) || 0) : 0;
  const dur = `${Math.floor(secs / 60)}:${String(secs % 60).padStart(2, '0')}`;
  el.recNote.textContent = rec.on
    ? `Recording: ${n} samples, ${dur}`
    : n ? `Stopped: ${n} samples, ${dur}` : 'Not recording';
  el.recNote.dataset.on = String(rec.on);
  el.recToggle.textContent = rec.on ? 'Stop recording' : n ? 'Resume recording' : 'Start recording';
  el.recDownload.disabled = n === 0;
  el.recClear.disabled = n === 0 || rec.on;
}

function downloadRec() {
  const text = [REC_COLUMNS.join(','), ...rec.rows].join('\n') + '\n';
  const blob = new Blob([text], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  const d = new Date();
  a.download = `fan-record-${d.toISOString().slice(0, 19).replace(/[T:]/g, '-')}.csv`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

async function adjust(unit, patch) {
  try {
    const r = await api.calibrate(unit, patch);
    if (r && r.offset !== undefined) {
      state.units[unit].calibration.offset = r.offset;
      state.units[unit].calibration.reverse = !!r.reverse;
      renderDiagnostics();
    }
  } catch (err) {
    toast(err.message, 'error');
  }
}

function buildCal(unit, label) {
  const root = document.createElement('div');
  root.className = 'cal-unit';
  const head = document.createElement('div');
  head.className = 'cal-head';
  const name = document.createElement('strong');
  name.textContent = label;
  const value = document.createElement('span');
  value.className = 'cal-value';
  head.append(name, value);

  const row = document.createElement('div');
  row.className = 'cal-row';
  const mk = (text, patch) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.className = 'btn';
    b.textContent = text;
    b.addEventListener('click', () => adjust(unit, patch));
    return b;
  };
  const coarseL = mk('-20°', { delta: -10 });
  const fineL = mk('-2°', { delta: -1 });
  const fineR = mk('+2°', { delta: 1 });
  const coarseR = mk('+20°', { delta: 10 });
  row.append(coarseL, fineL, fineR, coarseR);

  const row2 = document.createElement('div');
  row2.className = 'cal-row';
  const reverse = document.createElement('button');
  reverse.type = 'button';
  reverse.className = 'btn cal-reverse';
  reverse.textContent = 'Reverse';
  reverse.addEventListener('click', () => adjust(unit, { reverse: !state.units[unit].calibration.reverse }));
  const zero = mk('Reset to 0', { offset: 0, reverse: false });
  zero.classList.add('btn-ghost');
  row2.append(reverse, zero);
  row2.style.gridTemplateColumns = '1fr 1fr';

  root.append(head, row, row2);
  cal[unit] = { root, value, reverse, buttons: [coarseL, fineL, fineR, coarseR, reverse, zero] };
  return root;
}

export function initDiagnostics() {
  el.rows = document.getElementById('diag-rows');
  el.scene = document.getElementById('diag-scene');
  el.rail = document.getElementById('diag-rail');
  el.log = document.getElementById('log');
  el.note = document.getElementById('log-note');
  el.download = document.getElementById('log-download');
  el.clear = document.getElementById('log-clear');
  el.download.addEventListener('click', download);
  el.clear.addEventListener('click', () => { lines = []; renderLog(); });

  el.recNote = document.getElementById('rec-note');
  el.recToggle = document.getElementById('rec-toggle');
  el.recDownload = document.getElementById('rec-download');
  el.recClear = document.getElementById('rec-clear');
  el.recToggle.addEventListener('click', () => setRecording(!rec.on));
  el.recDownload.addEventListener('click', downloadRec);
  el.recClear.addEventListener('click', () => { rec.rows = []; renderRec(); });
  subscribeStatus(recSample);
  renderRec();

  el.cells = [];
  for (const [label] of ROWS) {
    const tr = document.createElement('tr');
    const th = document.createElement('td');
    th.textContent = label;
    const a = document.createElement('td');
    const b = document.createElement('td');
    tr.append(th, a, b);
    el.rows.appendChild(tr);
    el.cells.push([a, b]);
  }

  const units = document.getElementById('cal-units');
  units.append(buildCal(1, 'Left'), buildCal(2, 'Right'));
}

export function setDiagnosticsVisible(on) {
  visible = on;
  clearInterval(pollTimer);
  pollTimer = null;
  if (on) {
    renderDiagnostics();
    pollLog();
    pollTimer = setInterval(pollLog, 1000);
  }
}

export function renderDiagnostics() {
  if (!visible) return;
  ROWS.forEach(([, get, bad], i) => {
    [1, 2].forEach((id, col) => {
      const u = state.units[id];
      const v = u.online ? get(u) : null;
      const cell = el.cells[i][col];
      const text = fmt(v);
      if (cell.textContent !== text) cell.textContent = text;
      cell.dataset.bad = String(!!(bad && v !== null && v !== undefined && bad(v)));
    });
  });

  const sc = state.scene;
  el.scene.textContent = `${sc.sync ? 'loop sync on' : 'no sync'}, ${sc.mirror ? 'mirrored' : 'not mirrored'}`;
  const r = state.rail;
  el.rail.textContent = r.online
    ? `${r.state}, ${r.positionMm.toFixed(1)} of ${r.travelMm.toFixed(0)} mm, direction ${r.direction}`
    : 'offline';

  for (const id of [1, 2]) {
    const u = state.units[id];
    const c = cal[id];
    c.root.dataset.off = String(!u.online);
    c.value.textContent = `${u.calibration.offset * 2}°${u.calibration.reverse ? ', reversed' : ''}`;
    c.reverse.setAttribute('aria-pressed', String(u.calibration.reverse));
    for (const b of c.buttons) b.disabled = !state.connection.online || !u.online;
  }
}
