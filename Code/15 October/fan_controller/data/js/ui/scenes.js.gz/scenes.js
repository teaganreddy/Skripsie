/*
 * ui/scenes.js -- the Scenes tab: one button per two-fan show.
 *
 * Pressing Play runs a short script against the same API the Control tab
 * uses, one step at a time, waiting for the device's own status to confirm
 * each before the next: Both mode, rail mode, one image per fan, start the
 * fans, and for a sweep scene start the rail. Every step can be refused by
 * the stator (fans running, rail not connected, right fan missing) and the
 * refusal is shown verbatim, the same as anywhere else on the site.
 *
 * The device does the timing that matters (loop pulses, rail-following
 * mirror); this file only sequences what a person would otherwise click.
 */

import { api } from '../api.js';
import { HW } from '../config.js';
import { SCENES } from '../scenes.js';
import { state, toast, unitStopped } from '../state.js';

const el = {};
let running = null; // { id, step } while a scene is being started
let cancelled = false;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* Poll the store until `test` passes or `ms` elapses. Status arrives every
 * 500 ms, so 250 ms polling is plenty. */
async function waitFor(test, ms, what) {
  const until = Date.now() + ms;
  while (Date.now() < until) {
    if (cancelled) throw new Error('Cancelled');
    if (test()) return;
    await sleep(250);
  }
  throw new Error(`Gave up waiting for ${what}`);
}

function setStep(text) {
  if (running) running.step = text;
  renderScenes();
}

function bothOnline() {
  return state.connection.online && state.units[1].online && state.units[2].online;
}

function fansStopped() {
  return unitStopped(state.units[1]) && unitStopped(state.units[2]);
}

function railIdle() {
  const r = state.rail;
  return r.online && r.homed && !r.moving && r.state === 'idle';
}

/* "The rotor holds this image": the stator names it AND is no longer pushing
 * it. rotorHasContent alone is not enough -- it stays true for the previous
 * image while the new one transfers. */
function showing(unitId, contentId) {
  const u = state.units[unitId];
  return u.content?.id === contentId && !u.pushing && u.rotorHasContent !== false;
}

async function play(scene) {
  if (running) return;
  if (!bothOnline()) return toast('Both fans have to be connected for a scene.', 'error');
  if (!state.rail.online) return toast('The rail is not connected.', 'error');
  if (!fansStopped()) return toast('Stop the fans first, then start a scene.', 'error');

  running = { id: scene.id, step: 'Starting' };
  cancelled = false;
  renderScenes();
  try {
    if (state.display.mode !== 'both') {
      setStep('Selecting both fans');
      await api.displayMode('both');
      await waitFor(() => state.display.mode === 'both', 5000, 'both fans');
    }

    if (!state.rail.homed) {
      setStep('Homing the rail');
      await api.railHome();
      await waitFor(() => state.rail.homed && state.rail.state === 'idle', 60000, 'the rail to home');
    }

    const railMode = scene.mode === 'sweep' ? 'sweep' : 'static';
    if (state.rail.mode !== railMode) {
      setStep(scene.mode === 'sweep' ? 'Setting the rail to sweep' : 'Setting the rail to position');
      await api.railMode(railMode);
      await waitFor(() => state.rail.mode === railMode, 5000, 'the rail mode');
    }

    if (scene.mode === 'position') {
      /* Park both fans in the middle. Entering Position mode centres on its
       * own, but if the rail was already in it the carriage is wherever it
       * was last left, so ask explicitly. The stator refuses to start fans
       * while the rail moves, hence the wait. */
      setStep('Centring the rail');
      await sleep(800);
      await waitFor(railIdle, 30000, 'the rail to settle');
      const t = state.rail.travelMm > 0 ? state.rail.travelMm : HW.RAIL_TRAVEL_MM;
      if (Math.abs(state.rail.positionMm - t / 2) > 3) {
        await api.railGoto(t / 2);
        await sleep(800);
        await waitFor(railIdle, 30000, 'the rail to centre');
      }
    } else {
      setStep('Stopping the rail');
      await api.railSweep({ on: false });
      await sleep(400);
      if (scene.fromHome) {
        /* The first leg has to start from HOME (flappy's file begins with the
         * leg toward the far end). A sweep heads for whichever end is
         * further, so from HOME that is the far end. Homing parks the
         * carriage at the soft limit, which is where the sweep starts; skip
         * it if the carriage is already there. Homing is allowed in Sweep
         * mode, and the fans are still stopped here. */
        await waitFor(railIdle, 30000, 'the rail to stop');
        if (state.rail.positionMm > HW.RAIL_SOFT_MARGIN_MM + 1) {
          setStep('Homing the rail');
          await api.railHome();
          await sleep(800);
          await waitFor(railIdle, 60000, 'the rail to home');
        }
      }
    }

    setStep('Sending the left image');
    await api.select(scene.left, 'left');
    setStep('Sending the right image');
    await api.select(scene.right, 'right');
    setStep('Waiting for both fans to load');
    await sleep(1500);  // let both pushes begin before trusting "not pushing"
    await waitFor(() => showing(1, scene.left) && showing(2, scene.right), 60000, 'the images');

    setStep('Starting the fans');
    await api.setPower(true);
    await waitFor(
      () => ['running', 'starting'].includes(state.units[1].state) &&
            ['running', 'starting'].includes(state.units[2].state),
      10000, 'the fans to start');

    if (scene.mode === 'sweep') {
      setStep('Waiting for speed');
      await waitFor(() => state.units[1].state === 'running' && state.units[2].state === 'running',
                    30000, 'the fans to reach speed');
      setStep('Starting the sweep');
      const t = state.rail.travelMm > 0 ? state.rail.travelMm : HW.RAIL_TRAVEL_MM;
      await api.railSweep({
        on: true,
        minMm: HW.RAIL_SOFT_MARGIN_MM,
        maxMm: t - HW.RAIL_SOFT_MARGIN_MM,
        speedMms: scene.sweepMms || HW.RAIL_SPEED_DEFAULT_MMS,
        dwellMs: HW.RAIL_DWELL_DEFAULT_MS,
      });
    }
    toast(`${scene.name} is playing`, 'success');
  } catch (err) {
    if (err.message !== 'Cancelled') toast(err.message, 'error');
  } finally {
    running = null;
    renderScenes();
  }
}

async function stopAll() {
  cancelled = true;
  try {
    if (state.rail.sweeping) await api.railSweep({ on: false });
    await api.setPower(false);
    toast('Stopping. The arms wind down under control.', 'info');
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function estop() {
  cancelled = true;
  try {
    await api.emergencyStop();
    toast('Emergency stop. The arms are still coasting.', 'info');
  } catch (err) {
    toast(err.message, 'error');
  }
}

export function initScenes() {
  el.grid = document.getElementById('scenes');
  el.note = document.getElementById('scenes-note');
  el.stop = document.getElementById('scenes-stop');
  el.estop = document.getElementById('scenes-estop');
  el.stop.addEventListener('click', stopAll);
  el.estop.addEventListener('click', estop);

  el.cards = {};
  for (const scene of SCENES) {
    const card = document.createElement('div');
    card.className = 'scene';
    card.dataset.mode = scene.mode;

    const thumbs = document.createElement('div');
    thumbs.className = 'scene-thumbs';
    for (const id of [scene.left, scene.right]) {
      const img = document.createElement('img');
      img.className = 'scene-thumb';
      img.alt = '';
      img.src = `presets/${encodeURIComponent(id)}.png`;
      thumbs.appendChild(img);
    }
    card.appendChild(thumbs);

    const body = document.createElement('div');
    body.className = 'scene-body';
    const head = document.createElement('div');
    head.className = 'scene-head';
    const name = document.createElement('strong');
    name.textContent = scene.name;
    const mode = document.createElement('span');
    mode.className = 'scene-mode';
    mode.textContent = scene.mode === 'sweep' ? 'Sweep' : 'Position';
    head.append(name, mode);
    const blurb = document.createElement('p');
    blurb.className = 'scene-blurb';
    blurb.textContent = scene.blurb;
    const status = document.createElement('p');
    status.className = 'scene-status';
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'btn btn-primary';
    btn.textContent = 'Play';
    btn.addEventListener('click', () => play(scene));
    body.append(head, blurb, status, btn);
    card.appendChild(body);

    el.grid.appendChild(card);
    el.cards[scene.id] = { card, btn, status };
  }
}

export function renderScenes() {
  const online = state.connection.online;
  const ready = bothOnline() && state.rail.online;
  const stopped = fansStopped();

  let note = '';
  if (!online) note = '';
  else if (!state.units[2].online) note = 'Right fan not connected';
  else if (!state.rail.online) note = 'Rail not connected';
  else if (!stopped && !running) note = 'A scene is playing. Stop the fans to start another.';
  el.note.textContent = note;

  for (const scene of SCENES) {
    const c = el.cards[scene.id];
    const isRunning = running?.id === scene.id;
    const live = !running && !stopped &&
      state.units[1].content?.id === scene.left && state.units[2].content?.id === scene.right;
    c.card.dataset.live = String(live || isRunning);
    c.btn.disabled = !ready || !!running || !stopped;
    c.btn.textContent = isRunning ? 'Starting…' : live ? 'Playing' : 'Play';
    c.status.textContent = isRunning ? running.step : '';
  }

  const anyRunning = !stopped;
  el.stop.disabled = !online || (!anyRunning && !running);
  el.estop.disabled = !online;
}
