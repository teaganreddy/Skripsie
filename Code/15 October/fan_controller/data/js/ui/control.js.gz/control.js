/*
 * ui/control.js -- power, speed, brightness, emergency stop, fault banner.
 *
 * Two things this panel has to get right:
 *
 *   1. Don't fight the user. Status arrives from the device every ~500 ms,
 *      and naively writing rpmTarget into the slider on every update yanks
 *      the thumb out from under a dragging finger. Sliders are therefore
 *      "owned" by the user while they're touching them, and only resync
 *      once the device has caught up.
 *
 *   2. Commands are debounced. Dragging a slider fires input events at
 *      display rate; a microcontroller does not want 60 POSTs a second.
 */

import { HW } from '../config.js';
import { api } from '../api.js';
import { state, activeUnit, activeUnits, anyActiveRunning, update, toast } from '../state.js';

const el = {};
let dragging = null; // 'rpm' | 'brightness' | null
let pendingResync = null;
let powerBusy = false;

function debounce(fn, ms) {
  let t = null;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

const sendSpeed = debounce(async (rpm) => {
  try {
    await api.setSpeed(rpm);
  } catch (err) {
    toast(err.message, 'error');
  }
}, 180);

const sendBrightness = debounce(async (level) => {
  try {
    await api.setBrightness(level);
  } catch (err) {
    toast(err.message, 'error');
  }
}, 180);

const STATE_LABEL = {
  idle: 'Idle',
  starting: 'Spinning up',
  running: 'Running',
  stopping: 'Slowing down',
  fault: 'Fault',
};

export function initControl() {
  el.power = document.getElementById('power');
  el.powerText = document.getElementById('power-text');
  el.rpm = document.getElementById('rpm');
  el.rpmOut = document.getElementById('rpm-out');
  el.rpmBand = document.getElementById('rpm-band');
  el.rpmNote = document.getElementById('rpm-note');
  el.bright = document.getElementById('brightness');
  el.brightOut = document.getElementById('bright-out');
  el.estop = document.getElementById('estop');
  el.fault = document.getElementById('fault');
  el.faultBody = document.getElementById('fault-body');
  el.faultClear = document.getElementById('fault-clear');

  el.rpm.min = HW.RPM_MIN;
  el.rpm.max = HW.RPM_MAX;
  el.rpm.step = HW.RPM_STEP;
  el.rpm.value = HW.RPM_DEFAULT;

  // Position the "POV works here" band to match the slider's own scale.
  //
  // Clamped to the slider, because the POV band and the slider range are set
  // independently: during firmware bring-up RPM_MAX is held well below
  // RPM_POV_MIN (the tested speed envelope does not reach the speed the image
  // forms at yet), and without clamping the band would be positioned off the
  // end of the track at a few hundred percent. Clamping collapses it to
  // nothing instead, which is the honest picture -- at those speeds there is
  // no band, because there is no persistence-of-vision effect.
  const span = HW.RPM_MAX - HW.RPM_MIN;
  const pct = (rpm) => Math.max(0, Math.min(100, ((rpm - HW.RPM_MIN) / span) * 100));
  const left = pct(HW.RPM_POV_MIN);
  const width = pct(HW.RPM_POV_MAX) - left;
  el.rpmBand.style.left = `${left}%`;
  el.rpmBand.style.width = `${width}%`;

  el.power.addEventListener('click', onPowerClick);
  el.estop.addEventListener('click', onStopClick);
  el.faultClear.addEventListener('click', onClearFault);

  bindSlider(el.rpm, 'rpm', (v) => {
    update((s) => {
      for (const u of activeUnits()) u.rpmTarget = v;
    });
    sendSpeed(v);
  });

  bindSlider(el.bright, 'brightness', (v) => {
    update((s) => {
      for (const u of activeUnits()) u.brightness = v;
    });
    sendBrightness(v);
  });
}

function bindSlider(input, key, onChange) {
  const start = () => {
    dragging = key;
    clearTimeout(pendingResync);
  };
  const end = () => {
    // Hold ownership briefly after release so the in-flight debounced command
    // has time to land and be reflected in status before we resync.
    clearTimeout(pendingResync);
    pendingResync = setTimeout(() => {
      dragging = null;
    }, 900);
  };

  input.addEventListener('pointerdown', start);
  input.addEventListener('keydown', start);
  input.addEventListener('pointerup', end);
  input.addEventListener('pointercancel', end);
  input.addEventListener('blur', end);
  input.addEventListener('change', end);
  input.addEventListener('input', () => onChange(Number(input.value)));
}

async function onPowerClick() {
  const targets = activeUnits();
  const faulted = targets.find((u) => u.fault);
  if (faulted) {
    toast(`Clear the ${faulted.label.toLowerCase()} fan's fault before starting`, 'error');
    return;
  }
  const turningOn = !anyActiveRunning();
  powerBusy = true;
  el.power.dataset.busy = 'true';
  el.power.disabled = true;

  // Optimistic: show the transitional state immediately rather than waiting
  // a round-trip. The device's own status will correct us if it disagrees.
  update((s) => {
    for (const u of targets) {
      u.power = turningOn;
      u.state = turningOn ? 'starting' : 'stopping';
    }
  });

  try {
    await api.setPower(turningOn);
  } catch (err) {
    update((s) => {
      for (const u of targets) {
        u.power = !turningOn;
        u.state = 'idle';
      }
    });
    toast(err.message, 'error');
  } finally {
    powerBusy = false;
    el.power.dataset.busy = 'false';
    el.power.disabled = false;
  }
}

async function onStopClick() {
  try {
    await api.emergencyStop();
    update((s) => {
      for (const u of Object.values(s.units)) {
        u.power = false;
        if (u.online) u.state = 'stopping';
      }
    });
    // Deliberately not "Stopped" -- the drive is off but the arm is still
    // turning, and telling a walk-up user otherwise would be a lie they could
    // reach out and touch.
    toast('Emergency stop. The arms are still coasting.', 'info');
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function onClearFault() {
  try {
    await api.clearFault();
    toast('Fault cleared', 'success');
  } catch (err) {
    toast(err.message, 'error');
  }
}

export function renderControl() {
  const unit = activeUnit();
  const online = state.connection.online;

  // --- Power: over the active set. Any of them running means "Stop". ---
  const targets = activeUnits();
  const on = anyActiveRunning();
  const states = targets.map((u) => u.state);
  el.power.setAttribute('aria-pressed', String(on));
  el.powerText.textContent =
    states.includes('starting') ? 'Starting…' :
    states.includes('stopping') ? 'Stopping…' :
    on ? 'Stop' : 'Start';
  const anyFault = targets.some((u) => u.fault);
  const anyOffline = targets.some((u) => !u.online);
  if (!powerBusy) el.power.disabled = !online || anyFault || (anyOffline && !on);

  // --- Speed ---
  if (dragging !== 'rpm') {
    /* ?? and not ||. The slider's bottom stop is now 0, which is falsy, so ||
     * would read a genuine "stopped" target as missing and snap the slider
     * back to RPM_DEFAULT the instant the user let go of it. */
    const target = unit.rpmTarget ?? HW.RPM_DEFAULT;
    if (Number(el.rpm.value) !== target) el.rpm.value = target;
  }
  const rpm = Number(el.rpm.value);
  el.rpmOut.innerHTML = `${rpm} <small>rpm</small>`;
  el.rpm.disabled = !online;

  if (rpm === 0) {
    el.rpmNote.textContent = 'Stopped. The arm winds down under control.';
  } else if (rpm < HW.RPM_POV_MIN) {
    el.rpmNote.textContent = 'Below the POV range, so expect visible flicker.';
  } else if (rpm > HW.RPM_POV_MAX) {
    el.rpmNote.textContent = 'Above the tested range: brighter, but noisier.';
  } else {
    const hz = ((rpm / 60) * HW.ARMS).toFixed(1);
    el.rpmNote.textContent = `Refreshes at ${hz} Hz with ${HW.ARMS} arms.`;
  }

  // --- Brightness ---
  if (dragging !== 'brightness') {
    if (Number(el.bright.value) !== unit.brightness) el.bright.value = unit.brightness;
  }
  const level = Number(el.bright.value);
  el.brightOut.innerHTML = `${Math.round((level / 31) * 100)}<small>%</small>`;
  el.bright.disabled = !online;

  el.estop.disabled = !online;

  // --- Faults: every faulted fan, each on its own line, named. ---
  const faulted = Object.values(state.units).filter((u) => u.online && u.fault);
  if (faulted.length) {
    el.fault.hidden = false;
    el.faultBody.textContent = '';
    for (const u of faulted) {
      const strong = document.createElement('strong');
      strong.textContent = `${u.label} fan${u.fault.code ? ` fault ${u.fault.code}` : ' fault'}`;
      const span = document.createElement('span');
      span.textContent = u.fault.message || 'The fan stopped itself.';
      el.faultBody.append(strong, span);
    }
  } else {
    el.fault.hidden = true;
  }
}

export { STATE_LABEL };
