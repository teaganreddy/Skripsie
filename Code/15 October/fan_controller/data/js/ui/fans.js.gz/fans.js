/*
 * ui/fans.js -- which fans the controls drive: Left, Right or Both.
 *
 * This is a pre-run choice. The device refuses to change it unless every fan
 * is stopped, and says so; the alternative -- auto-stopping a spinning arm
 * because someone tapped a button -- is exactly the kind of surprise a
 * walk-up demo should not have. The three buttons grey out whenever the
 * device reports it would refuse, so the common case never errors.
 *
 * Same requested-mode-until-echoed pattern as the rail selector, for the same
 * reason: status arrives every 500 ms and would otherwise flip the buttons
 * back and forth while the POST is in flight.
 */

import { api } from '../api.js';
import { state, toast } from '../state.js';

const el = {};
let pendingMode = null;
let pendingModeUntil = 0;

function shownMode() {
  if (pendingMode) {
    if (state.display.mode === pendingMode || Date.now() > pendingModeUntil) pendingMode = null;
    else return pendingMode;
  }
  return state.display.mode;
}

export function initFans() {
  el.note = document.getElementById('fans-note');
  el.left = document.getElementById('fans-left');
  el.right = document.getElementById('fans-right');
  el.both = document.getElementById('fans-both');
  el.left.addEventListener('click', () => setMode('left'));
  el.right.addEventListener('click', () => setMode('right'));
  el.both.addEventListener('click', () => setMode('both'));
}

async function setMode(mode) {
  if (shownMode() === mode) return;
  pendingMode = mode;
  pendingModeUntil = Date.now() + 2500;
  renderFans();
  try {
    await api.displayMode(mode);
  } catch (err) {
    pendingMode = null;
    renderFans();
    toast(err.message, 'error');
  }
}

export function renderFans() {
  const online = state.connection.online;
  const mode = shownMode();
  const can = online && state.display.canChangeMode;
  const rightOnline = state.units[2].online;

  el.left.setAttribute('aria-checked', String(mode === 'left'));
  el.right.setAttribute('aria-checked', String(mode === 'right'));
  el.both.setAttribute('aria-checked', String(mode === 'both'));

  el.left.disabled = !can;
  el.right.disabled = !can || !rightOnline;
  el.both.disabled = !can || !rightOnline;

  if (!online) {
    el.note.textContent = '';
  } else if (!state.display.canChangeMode) {
    el.note.textContent = 'Stop the fans to change this';
  } else if (!rightOnline) {
    el.note.textContent = 'Right fan not connected';
  } else {
    el.note.textContent = '';
  }
}
