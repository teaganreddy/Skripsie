/*
 * ui/status.js -- read-only telemetry, one column per fan.
 *
 * Everything here is reported by the firmware; the UI computes nothing about
 * the machine's safety or health, it only presents it. The one derived value
 * is refresh rate, which is just measured RPM x arms / 60.
 *
 * Both columns are always live. The one the controls are not driving is
 * dimmed rather than hidden, so you can see that it really is stopped.
 */

import { HW } from '../config.js';
import { state, activeUnits } from '../state.js';
import { STATE_LABEL } from './control.js';

const cols = {};

export function initStatus() {
  for (const id of [1, 2]) {
    cols[id] = {
      root: document.getElementById(`unit-${id}`),
      pill: document.getElementById(`u${id}-pill`),
      rpm: document.getElementById(`u${id}-rpm`),
      refresh: document.getElementById(`u${id}-refresh`),
      link: document.getElementById(`u${id}-link`),
      rotorRpm: document.getElementById(`u${id}-rotor-rpm`),
      content: document.getElementById(`u${id}-content`),
      name: document.querySelector(`#unit-${id} .unit-name`),
    };
  }
}

export function renderStatus() {
  const connected = state.connection.online;
  const active = new Set(activeUnits().map((u) => u.id));

  for (const id of [1, 2]) {
    const unit = state.units[id];
    const c = cols[id];
    const online = connected && unit.online;

    c.root.dataset.active = String(active.has(id));
    c.name.textContent = unit.label;

    c.pill.dataset.state = online ? unit.state : 'offline';
    c.pill.textContent = !connected
      ? 'Offline'
      : !unit.online
        ? 'Not connected'
        : (STATE_LABEL[unit.state] ?? unit.state);

    c.rpm.textContent = online && unit.rpmActual ? Math.round(unit.rpmActual) : '-';

    const hz = online && unit.rpmActual ? (unit.rpmActual / 60) * HW.ARMS : 0;
    c.refresh.textContent = hz ? hz.toFixed(1) : '-';

    const rotor = unit.rotor;
    if (!online) c.link.textContent = '-';
    else if (!rotor.online) c.link.textContent = 'Down';
    else if (rotor.rssi != null) c.link.textContent = `${rotor.rssi} dBm`;
    else c.link.textContent = 'Up';

    /* Blanked when either link is down: whatever the rotor last reported is
     * stale and must not be shown as live. Zero is a genuine reading. */
    const rotorRpm = online && rotor.online ? rotor.rpm : null;
    c.rotorRpm.textContent = rotorRpm == null ? '-' : Math.round(rotorRpm);

    c.content.textContent = online ? (unit.content?.name || 'Nothing loaded') : '-';
  }
}
