/*
 * state.js -- tiny observable store.
 *
 * Deliberately about 40 lines of mechanism rather than a framework. The UI is
 * small enough that "hold a plain object, notify listeners on change" covers
 * everything, and it keeps the flashed bundle in the low tens of kilobytes.
 *
 * TWO FAN UNITS. `units` holds both, `display.mode` says which the controls
 * drive (left / right / both), and the panels read through activeUnit() /
 * activeUnits() rather than reaching for a single global. The rail is one
 * board shared by both fans, so it lives at the top level, not per unit.
 */

const listeners = new Set();

function makeUnit(id, label) {
  return {
    id,
    label,
    online: false, // the stator has heard from this unit recently
    power: false,
    state: 'offline', // offline | idle | starting | running | stopping | fault
    rpmTarget: 0,
    rpmActual: 0,
    /* The ramp's output, the setpoint the speed loop is chasing right now
     * (rpmTarget is where it is heading). Reported for unit 1 only. */
    rpmCommand: null,
    brightness: 24,
    fault: null, // { code, message } when latched
    rotor: {
      online: false,
      batteryPct: null,
      batteryMv: null,
      rssi: null,
      /* Measured by the rotor's OWN Hall sensor, not by the motor's encoder.
       * Null until the device reports one, so the panel can tell "not heard
       * from" apart from a genuine zero. */
      rpm: null,
    },
    content: null, // { id, name }
    /* The stator's word on whether the rotor actually holds the image, as
     * opposed to having been told to load it. The Scenes tab waits on this
     * before starting the fans. Null until reported. */
    rotorHasContent: null,
    /* The unit's stator is transferring content to its rotor right now. */
    pushing: false,
    /* Bring-up numbers, straight from the firmware, for the Diagnostics tab.
     * Null until reported; unit 2 relays fewer of them than unit 1. */
    diag: {
      focLoopHz: null, focMaxGapMs: null, voltageQ: null, rpmRipple: null,
      columnsPerSec: null, overruns: null, rejected: null, syncLocked: null,
      hall: null, // raw Hall input level: 1 high (no magnet), 0 low
    },
    /* Angle calibration held on the stator: offset in 2-degree sectors and
     * whether the rotation is reversed. Adjusted from the Diagnostics tab. */
    calibration: { offset: 0, reverse: false },
  };
}

export const state = {
  connection: { online: false, detail: '', since: null },

  /* Which fans the controls drive. Held on the master stator; changing it is
   * refused unless every fan is stopped, and canChangeMode is the stator's
   * own verdict on that so the selector greys for the right reason. */
  display: { mode: 'left', canChangeMode: true },

  units: { 1: makeUnit(1, 'Left'), 2: makeUnit(2, 'Right') },

  /* In Both mode, where the next image selection goes. UI-only; the stator is
   * told the target with each selection. */
  contentTarget: 'both', // both | left | right

  /* The linear rail, one board carrying both fans. `mode` is held on the
   * stator: 'static' = position the fans and display, 'sweep' = glide side
   * to side while they run. */
  rail: {
    online: false,
    mode: 'static',
    state: 'offline', // unhomed | homing | idle | moving | sweeping | measuring | fault
    homed: false,
    moving: false,
    sweeping: false,
    positionMm: 0,
    targetMm: 0,
    travelMm: 0,
    canMove: false, // the stator's interlock verdict right now
    direction: 0,   // +1 toward the far end, -1 toward home, 0 still
    fault: null,    // { code, message }
    sweep: { minMm: 0, maxMm: 0, speedMms: 0, dwellMs: 0 },
  },

  /* What the master is doing for a two-fan scene: sending loop pulses so both
   * fans play in step, and whether the content is currently mirrored (the
   * rail is carrying the fans left). Display only. */
  scene: { sync: false, mirror: false },

  library: [], // [{ id, name, kind: 'preset'|'user', frames, fps, bytes }]

  /* Transient UI concerns, kept here so panels don't have to talk to each other. */
  upload: {
    busy: false,
    stage: null, // 'converting' | 'uploading' | 'publishing'
    progress: 0,
    message: '',
    error: null,
  },

  toast: null,
};

export function subscribeState(fn) {
  listeners.add(fn);
  fn(state);
  return () => listeners.delete(fn);
}

export function notify() {
  for (const fn of listeners) fn(state);
}

/* Called once per status packet from the device (not on every UI change, as
 * subscribeState is), after the packet has been applied. For the Record
 * panel on the Diagnostics tab, which logs one row per packet. */
const statusListeners = new Set();
export function subscribeStatus(fn) {
  statusListeners.add(fn);
  return () => statusListeners.delete(fn);
}

/** Shallow-merge a patch into a slice of state, then notify once. */
export function update(mutator) {
  mutator(state);
  notify();
}

/** The fans the controls currently drive, in unit order. */
export function activeUnits() {
  const m = state.display.mode;
  if (m === 'right') return [state.units[2]];
  if (m === 'both') return [state.units[1], state.units[2]];
  return [state.units[1]];
}

/** The unit whose figures the shared sliders read back from. In Both mode the
 *  two are commanded together, so the left one stands for both. */
export function activeUnit() {
  return state.display.mode === 'right' ? state.units[2] : state.units[1];
}

/** The unit whose content the Image panel previews and selects for. */
export function targetUnit() {
  if (state.display.mode === 'both') {
    return state.contentTarget === 'right' ? state.units[2] : state.units[1];
  }
  return activeUnit();
}

const MOVING_STATES = new Set(['starting', 'running', 'stopping']);

export function unitStopped(u) {
  return !u.online || (!u.power && !MOVING_STATES.has(u.state) && Math.abs(u.rpmActual || 0) <= 5);
}

export function anyActiveRunning() {
  return activeUnits().some((u) => u.online && (u.power || MOVING_STATES.has(u.state)));
}

/**
 * Fold a /api/status payload into the store.
 *
 * Tolerant of missing fields so a half-implemented firmware doesn't blank
 * the UI -- anything absent simply keeps its previous value. Also accepts
 * the older single-unit shape ({ unit: {...} }), which a stator that has not
 * been reflashed still sends: it becomes unit 1, with unit 2 offline.
 */
export function applyStatus(payload) {
  let units = payload.units;
  let rail = payload.rail;
  if (!Array.isArray(units) && payload.unit) {
    units = [{ id: 1, online: true, ...payload.unit }];
    rail = rail ?? payload.unit.rail;
  }

  if (Array.isArray(units)) {
    const seen = new Set();
    for (const u of units) {
      const target = state.units[u.id];
      if (!target) continue;
      seen.add(u.id);
      if (u.label !== undefined) target.label = u.label;
      target.online = u.online !== undefined ? !!u.online : true;
      if (u.state !== undefined) target.state = u.state;
      if (u.power !== undefined) target.power = !!u.power;
      if (u.rpmTarget !== undefined) target.rpmTarget = u.rpmTarget;
      if (u.rpmActual !== undefined) target.rpmActual = u.rpmActual;
      if (u.rpmCommand !== undefined) target.rpmCommand = u.rpmCommand;
      if (u.brightness !== undefined) target.brightness = u.brightness;
      if (u.fault !== undefined) target.fault = u.fault;
      if (u.content !== undefined) target.content = u.content;
      if (u.rotor) Object.assign(target.rotor, u.rotor);
      /* The firmware reports the rotor's Hall-measured speed as a flat
       * `rotorRpm`; fold it into the rotor object so the panel has one place
       * to look for rotor telemetry. */
      if (u.rotorRpm !== undefined) target.rotor.rpm = u.rotorRpm;
      if (u.rotorHasContent !== undefined) target.rotorHasContent = !!u.rotorHasContent;
      if (u.pushing !== undefined) target.pushing = !!u.pushing;
      const d = target.diag;
      if (u.focLoopHz !== undefined) d.focLoopHz = u.focLoopHz;
      if (u.focMaxGapMs !== undefined) d.focMaxGapMs = u.focMaxGapMs;
      if (u.voltageQ !== undefined) d.voltageQ = u.voltageQ;
      if (u.rpmRipple !== undefined) d.rpmRipple = u.rpmRipple;
      if (u.rotorColumnsPerSec !== undefined) d.columnsPerSec = u.rotorColumnsPerSec;
      if (u.rotorOverruns !== undefined) d.overruns = u.rotorOverruns;
      if (u.rotorRejected !== undefined) d.rejected = u.rotorRejected;
      if (u.rotorSyncLocked !== undefined) d.syncLocked = !!u.rotorSyncLocked;
      if (u.rotorHall !== undefined) d.hall = u.rotorHall;
      if (u.calibration) Object.assign(target.calibration, u.calibration);
    }
    for (const id of [1, 2]) {
      if (!seen.has(id)) {
        state.units[id].online = false;
        state.units[id].state = 'offline';
      }
    }
  }

  if (payload.display) {
    if (payload.display.mode !== undefined) state.display.mode = payload.display.mode;
    if (payload.display.canChangeMode !== undefined) {
      state.display.canChangeMode = !!payload.display.canChangeMode;
    }
  }

  if (rail) {
    const { sweep, ...rest } = rail;
    Object.assign(state.rail, rest);
    if (sweep) Object.assign(state.rail.sweep, sweep);
  }

  if (payload.scene) Object.assign(state.scene, payload.scene);

  if (Array.isArray(payload.library)) state.library = payload.library;

  notify();
  for (const fn of statusListeners) fn(state);
}

export function setConnection(online, detail = '') {
  const c = state.connection;
  if (c.online === online && c.detail === detail) return;
  c.online = online;
  c.detail = detail;
  if (online && !c.since) c.since = Date.now();
  if (!online) c.since = null;
  notify();
}

let toastTimer = null;
export function toast(message, kind = 'info', ms = 3500) {
  state.toast = { message, kind, at: Date.now() };
  notify();
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    state.toast = null;
    notify();
  }, ms);
}
