/*
 * state.js -- tiny observable store.
 *
 * Deliberately about 40 lines rather than a framework. The UI is small enough
 * that "hold a plain object, notify listeners on change" covers everything,
 * and it keeps the flashed bundle in the low tens of kilobytes.
 *
 * The `units` map is the hook for multi-fan support (FR16 / TPM08). v1 only
 * ever populates the 'primary' entry, but panels read through selectUnit()
 * rather than reaching for a single global, so adding a second unit later is
 * a matter of populating the map and adding a picker -- not a rewrite.
 */

const listeners = new Set();

export const state = {
  connection: { online: false, detail: '', since: null },

  activeUnit: 'primary',
  units: {
    primary: {
      id: 'primary',
      name: 'Fan 1',
      power: false,
      state: 'idle', // idle | starting | running | stopping | fault
      rpmTarget: 0,
      rpmActual: 0,
      brightness: 24,
      fault: null, // { code, message } when latched
      rotor: {
        online: false,
        batteryPct: null,
        batteryMv: null,
        rssi: null,
        /* Measured by the rotor's OWN Hall sensor, not by the motor's encoder.
         * Null until the device reports one, so the panel can tell "not heard
         * from" apart from a genuine zero. */
        rpm: null,
      },
      content: null, // { id, name }
      /* The linear rail, a third board. `mode` is held on the stator so it
       * survives a page reload: 'static' = position the fan and display,
       * 'sweep' = glide side to side while the fan runs. */
      rail: {
        online: false,
        mode: 'static',
        state: 'offline', // unhomed | homing | idle | moving | sweeping | measuring | fault
        homed: false,
        moving: false,
        sweeping: false,
        positionMm: 0,
        targetMm: 0,
        travelMm: 0,
        canMove: false, // the stator's interlock verdict right now
        fault: null,    // { code, message }
        sweep: { minMm: 0, maxMm: 0, speedMms: 0, dwellMs: 0 },
      },
    },
  },

  library: [], // [{ id, name, kind: 'preset'|'user', frames, fps, bytes }]

  /* Transient UI concerns, kept here so panels don't have to talk to each other. */
  upload: {
    busy: false,
    stage: null, // 'converting' | 'uploading' | 'publishing'
    progress: 0,
    message: '',
    error: null,
  },

  toast: null,
};

export function subscribeState(fn) {
  listeners.add(fn);
  fn(state);
  return () => listeners.delete(fn);
}

export function notify() {
  for (const fn of listeners) fn(state);
}

/** Shallow-merge a patch into a slice of state, then notify once. */
export function update(mutator) {
  mutator(state);
  notify();
}

export function activeUnit() {
  return state.units[state.activeUnit];
}

/**
 * Fold a /api/status payload into the store.
 * Tolerant of missing fields so a half-implemented firmware doesn't blank
 * the UI -- anything absent simply keeps its previous value.
 */
export function applyStatus(payload) {
  const unit = activeUnit();
  const u = payload.unit ?? payload;

  if (u.state !== undefined) unit.state = u.state;
  if (u.power !== undefined) unit.power = !!u.power;
  if (u.rpmTarget !== undefined) unit.rpmTarget = u.rpmTarget;
  if (u.rpmActual !== undefined) unit.rpmActual = u.rpmActual;
  if (u.brightness !== undefined) unit.brightness = u.brightness;
  if (u.fault !== undefined) unit.fault = u.fault;
  if (u.content !== undefined) unit.content = u.content;

  if (u.rotor) {
    Object.assign(unit.rotor, u.rotor);
  }

  /* The firmware reports the rotor's Hall-measured speed as a flat
   * `unit.rotorRpm` rather than inside `unit.rotor` -- it arrived with the
   * bring-up diagnostics, which are all flat. Fold it into the rotor object so
   * the panel has one place to look for rotor telemetry. */
  if (u.rotorRpm !== undefined) unit.rotor.rpm = u.rotorRpm;

  if (u.rail) {
    const { sweep, ...rest } = u.rail;
    Object.assign(unit.rail, rest);
    if (sweep) Object.assign(unit.rail.sweep, sweep);
  }

  if (Array.isArray(payload.library)) state.library = payload.library;

  notify();
}

export function setConnection(online, detail = '') {
  const c = state.connection;
  if (c.online === online && c.detail === detail) return;
  c.online = online;
  c.detail = detail;
  if (online && !c.since) c.since = Date.now();
  if (!online) c.since = null;
  notify();
}

let toastTimer = null;
export function toast(message, kind = 'info', ms = 3500) {
  state.toast = { message, kind, at: Date.now() };
  notify();
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    state.toast = null;
    notify();
  }, ms);
}
