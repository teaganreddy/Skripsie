/*
 * ui/control.js -- power, speed, brightness, emergency stop, fault banner.
 *
 * Two things this panel has to get right:
 *
 *   1. Don't fight the user. Status arrives from the device every ~500 ms,
 *      and naively writing rpmTarget into the slider on every update yanks
 *      the thumb out from under a dragging finger. Sliders are therefore
 *      "owned" by the user while they're touching them, and only resync
 *      once the device has caught up.
 *
 *   2. Commands are debounced. Dragging a slider fires input events at
 *      display rate; a microcontroller does not want 60 POSTs a second.
 */

import { HW } from '../config.js';
import { api } from '../api.js';
import { state, activeUnit, update, toast } from '../state.js';

const el = {};
let dragging = null; // 'rpm' | 'brightness' | null
let pendingResync = null;
let powerBusy = false;

function debounce(fn, ms) {
  let t = null;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
}

const sendSpeed = debounce(async (rpm) => {
  try {
    await api.setSpeed(rpm);
  } catch (err) {
    toast(err.message, 'error');
  }
}, 180);

const sendBrightness = debounce(async (level) => {
  try {
    await api.setBrightness(level);
  } catch (err) {
    toast(err.message, 'error');
  }
}, 180);

const STATE_LABEL = {
  idle: 'Idle',
  starting: 'Spinning up',
  running: 'Running',
  stopping: 'Slowing down',
  fault: 'Fault',
};

export function initControl() {
  el.power = document.getElementById('power');
  el.powerText = document.getElementById('power-text');
  el.rpm = document.getElementById('rpm');
  el.rpmOut = document.getElementById('rpm-out');
  el.rpmBand = document.getElementById('rpm-band');
  el.rpmNote = document.getElementById('rpm-note');
  el.bright = document.getElementById('brightness');
  el.brightOut = document.getElementById('bright-out');
  el.estop = document.getElementById('estop');
  el.fault = document.getElementById('fault');
  el.faultTitle = document.getElementById('fault-title');
  el.faultMessage = document.getElementById('fault-message');
  el.faultClear = document.getElementById('fault-clear');

  el.rpm.min = HW.RPM_MIN;
  el.rpm.max = HW.RPM_MAX;
  el.rpm.step = HW.RPM_STEP;
  el.rpm.value = HW.RPM_DEFAULT;

  // Position the "POV works here" band to match the slider's own scale.
  //
  // Clamped to the slider, because the POV band and the slider range are set
  // independently: during firmware bring-up RPM_MAX is held well below
  // RPM_POV_MIN (the tested speed envelope does not reach the speed the image
  // forms at yet), and without clamping the band would be positioned off the
  // end of the track at a few hundred percent. Clamping collapses it to
  // nothing instead, which is the honest picture -- at those speeds there is
  // no band, because there is no persistence-of-vision effect.
  const span = HW.RPM_MAX - HW.RPM_MIN;
  const pct = (rpm) => Math.max(0, Math.min(100, ((rpm - HW.RPM_MIN) / span) * 100));
  const left = pct(HW.RPM_POV_MIN);
  const width = pct(HW.RPM_POV_MAX) - left;
  el.rpmBand.style.left = `${left}%`;
  el.rpmBand.style.width = `${width}%`;

  el.power.addEventListener('click', onPowerClick);
  el.estop.addEventListener('click', onStopClick);
  el.faultClear.addEventListener('click', onClearFault);

  bindSlider(el.rpm, 'rpm', (v) => {
    update((s) => {
      activeUnit().rpmTarget = v;
    });
    sendSpeed(v);
  });

  bindSlider(el.bright, 'brightness', (v) => {
    update((s) => {
      activeUnit().brightness = v;
    });
    sendBrightness(v);
  });
}

function bindSlider(input, key, onChange) {
  const start = () => {
    dragging = key;
    clearTimeout(pendingResync);
  };
  const end = () => {
    // Hold ownership briefly after release so the in-flight debounced command
    // has time to land and be reflected in status before we resync.
    clearTimeout(pendingResync);
    pendingResync = setTimeout(() => {
      dragging = null;
    }, 900);
  };

  input.addEventListener('pointerdown', start);
  input.addEventListener('keydown', start);
  input.addEventListener('pointerup', end);
  input.addEventListener('pointercancel', end);
  input.addEventListener('blur', end);
  input.addEventListener('change', end);
  input.addEventListener('input', () => onChange(Number(input.value)));
}

async function onPowerClick() {
  const unit = activeUnit();
  if (unit.fault) {
    toast('Clear the fault before starting', 'error');
    return;
  }
  const turningOn = !unit.power;
  powerBusy = true;
  el.power.dataset.busy = 'true';
  el.power.disabled = true;

  // Optimistic: show the transitional state immediately rather than waiting
  // a round-trip. The device's own status will correct us if it disagrees.
  update((s) => {
    unit.power = turningOn;
    unit.state = turningOn ? 'starting' : 'stopping';
  });

  try {
    await api.setPower(turningOn);
  } catch (err) {
    update((s) => {
      unit.power = !turningOn;
      unit.state = 'idle';
    });
    toast(err.message, 'error');
  } finally {
    powerBusy = false;
    el.power.dataset.busy = 'false';
    el.power.disabled = false;
  }
}

async function onStopClick() {
  try {
    await api.emergencyStop();
    update((s) => {
      const u = activeUnit();
      u.power = false;
      u.state = 'stopping';
    });
    // Deliberately not "Stopped" -- the drive is off but the arm is still
    // turning, and telling a walk-up user otherwise would be a lie they could
    // reach out and touch.
    toast('Emergency stop. The arm is still coasting.', 'info');
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function onClearFault() {
  try {
    await api.clearFault();
    toast('Fault cleared', 'success');
  } catch (err) {
    toast(err.message, 'error');
  }
}

export function renderControl() {
  const unit = activeUnit();
  const online = state.connection.online;

  // --- Power ---
  const on = unit.power;
  el.power.setAttribute('aria-pressed', String(on));
  el.powerText.textContent =
    unit.state === 'starting' ? 'Starting…' :
    unit.state === 'stopping' ? 'Stopping…' :
    on ? 'Stop' : 'Start';
  if (!powerBusy) el.power.disabled = !online || Boolean(unit.fault);

  // --- Speed ---
  if (dragging !== 'rpm') {
    /* ?? and not ||. The slider's bottom stop is now 0, which is falsy, so ||
     * would read a genuine "stopped" target as missing and snap the slider
     * back to RPM_DEFAULT the instant the user let go of it. */
    const target = unit.rpmTarget ?? HW.RPM_DEFAULT;
    if (Number(el.rpm.value) !== target) el.rpm.value = target;
  }
  const rpm = Number(el.rpm.value);
  el.rpmOut.innerHTML = `${rpm} <small>rpm</small>`;
  el.rpm.disabled = !online;

  if (rpm === 0) {
    el.rpmNote.textContent = 'Stopped. The arm winds down under control.';
  } else if (rpm < HW.RPM_POV_MIN) {
    el.rpmNote.textContent = 'Below the POV range, so expect visible flicker.';
  } else if (rpm > HW.RPM_POV_MAX) {
    el.rpmNote.textContent = 'Above the tested range: brighter, but noisier.';
  } else {
    const hz = ((rpm / 60) * HW.ARMS).toFixed(1);
    el.rpmNote.textContent = `Refreshes at ${hz} Hz with ${HW.ARMS} arms.`;
  }

  // --- Brightness ---
  if (dragging !== 'brightness') {
    if (Number(el.bright.value) !== unit.brightness) el.bright.value = unit.brightness;
  }
  const level = Number(el.bright.value);
  el.brightOut.innerHTML = `${Math.round((level / 31) * 100)}<small>%</small>`;
  el.bright.disabled = !online;

  el.estop.disabled = !online;

  // --- Fault ---
  if (unit.fault) {
    el.fault.hidden = false;
    el.faultTitle.textContent = unit.fault.code ? `Fault ${unit.fault.code}` : 'Fault';
    el.faultMessage.textContent = unit.fault.message || 'The fan stopped itself.';
  } else {
    el.fault.hidden = true;
  }
}

export { STATE_LABEL };
