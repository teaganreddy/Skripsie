/*
 * ui/rail.js -- the linear rail panel.
 *
 * Two modes, chosen with the segmented control at the top:
 *
 *   Position  park the fan somewhere on the rail, then use it as normal. The
 *             rail only moves while the fan is stopped, and the stator
 *             refuses to start the fan while the rail is moving.
 *
 *   Sweep     glide side to side between two points while the fan plays, for
 *             content like a car driving across. The range is one slider,
 *             a width centred on the middle of the rail, because two
 *             independent end sliders were harder to explain to a walk-up
 *             user than "how far should it go".
 *
 * The UI never decides whether a move is safe. It sends the request and the
 * stator answers 409 with a plain-English reason if it is refused; that
 * reason goes straight into a toast. What the UI does do is grey out controls
 * the stator has already said it would refuse (`canMove`, `homed`), so the
 * common case never produces an error at all.
 */

import { HW } from '../config.js';
import { api } from '../api.js';
import { state, activeUnit, update, toast } from '../state.js';

const el = {};
let dragging = null; // 'pos' | 'span' | 'speed' | null
let pendingResync = null;
let busy = false;

const STATE_LABEL = {
  offline: 'Not connected',
  unhomed: 'Needs homing',
  homing: 'Homing',
  idle: 'Ready',
  moving: 'Moving',
  sweeping: 'Sweeping',
  measuring: 'Measuring',
  fault: 'Fault',
};

export function initRail() {
  el.status = document.getElementById('rail-status');
  el.modeStatic = document.getElementById('rail-mode-static');
  el.modeSweep = document.getElementById('rail-mode-sweep');
  el.fault = document.getElementById('rail-fault');
  el.faultMessage = document.getElementById('rail-fault-message');
  el.faultClear = document.getElementById('rail-fault-clear');
  el.trackFan = document.getElementById('track-fan');
  el.trackSweep = document.getElementById('track-sweep');

  el.paneStatic = document.getElementById('rail-pane-static');
  el.pos = document.getElementById('rail-pos');
  el.posOut = document.getElementById('rail-pos-out');
  el.staticNote = document.getElementById('rail-static-note');
  el.move = document.getElementById('rail-move');
  el.stop = document.getElementById('rail-stop');
  el.centre = document.getElementById('rail-centre');
  el.home = document.getElementById('rail-home');

  el.paneSweep = document.getElementById('rail-pane-sweep');
  el.span = document.getElementById('rail-span');
  el.spanOut = document.getElementById('rail-span-out');
  el.speed = document.getElementById('rail-speed');
  el.speedOut = document.getElementById('rail-speed-out');
  el.sweepNote = document.getElementById('rail-sweep-note');
  el.sweepStart = document.getElementById('rail-sweep-start');
  el.sweepStop = document.getElementById('rail-sweep-stop');

  el.speed.min = HW.RAIL_SPEED_MIN_MMS;
  el.speed.max = HW.RAIL_SPEED_MAX_MMS;
  el.speed.value = HW.RAIL_SPEED_DEFAULT_MMS;

  el.modeStatic.addEventListener('click', () => setMode('static'));
  el.modeSweep.addEventListener('click', () => setMode('sweep'));
  el.faultClear.addEventListener('click', guard(() => api.railClear(), 'Rail fault cleared'));
  /* The slider only PICKS a position. Nothing moves until Move is pressed,
   * so a walk-up user dragging to see what it does cannot set the rail off. */
  el.move.addEventListener('click', guard(() => api.railGoto(Number(el.pos.value)), null));
  el.stop.addEventListener('click', guard(() => api.railStop(), 'Rail stopped'));
  el.centre.addEventListener('click', guard(() => {
    el.pos.value = travel() / 2;
    return api.railGoto(travel() / 2);
  }, null));
  el.home.addEventListener('click', guard(() => api.railHome(), 'Homing the rail'));
  el.sweepStart.addEventListener('click', guard(() => api.railSweep(sweepRequest()), 'Sweeping'));
  el.sweepStop.addEventListener('click', guard(() => api.railSweep({ on: false }), 'Sweep stopped'));

  bindSlider(el.pos, 'pos', () => renderRail());
  bindSlider(el.span, 'span', () => {});
  bindSlider(el.speed, 'speed', () => {});
}

function travel() {
  const r = activeUnit().rail;
  return r.travelMm > 0 ? r.travelMm : HW.RAIL_TRAVEL_MM;
}

function sweepRequest() {
  const t = travel();
  const usable = t - 2 * HW.RAIL_SOFT_MARGIN_MM;
  const width = (Number(el.span.value) / 100) * usable;
  const mid = t / 2;
  return {
    on: true,
    minMm: mid - width / 2,
    maxMm: mid + width / 2,
    speedMms: Number(el.speed.value),
    dwellMs: HW.RAIL_DWELL_DEFAULT_MS,
  };
}

/* Wrap a command: disable the panel's buttons while it is in flight, toast the
 * outcome. The stator's refusal message is the toast text on failure. */
function guard(fn, okMessage) {
  return async () => {
    if (busy) return;
    busy = true;
    renderRail();
    try {
      await fn();
      if (okMessage) toast(okMessage, 'success');
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      busy = false;
      renderRail();
    }
  };
}

async function setMode(mode) {
  const rail = activeUnit().rail;
  if (rail.mode === mode) return;
  update(() => {
    rail.mode = mode; // optimistic; status corrects us if refused
  });
  try {
    await api.railMode(mode);
  } catch (err) {
    toast(err.message, 'error');
  }
}

function bindSlider(input, key, onChange) {
  const start = () => {
    dragging = key;
    clearTimeout(pendingResync);
  };
  const end = () => {
    clearTimeout(pendingResync);
    pendingResync = setTimeout(() => {
      dragging = null;
    }, 900);
  };
  input.addEventListener('pointerdown', start);
  input.addEventListener('keydown', start);
  input.addEventListener('pointerup', end);
  input.addEventListener('pointercancel', end);
  input.addEventListener('blur', end);
  input.addEventListener('change', end);
  input.addEventListener('input', () => onChange(Number(input.value)));
}

export function renderRail() {
  const unit = activeUnit();
  const rail = unit.rail;
  const online = state.connection.online && rail.online;
  const t = travel();
  const isStatic = rail.mode !== 'sweep';

  // --- header status ---
  if (!state.connection.online) {
    el.status.textContent = 'Not connected';
  } else if (!rail.online) {
    el.status.textContent = 'Rail not connected';
  } else if (rail.state === 'fault') {
    el.status.textContent = 'Fault';
  } else if (!rail.homed) {
    el.status.textContent = rail.state === 'homing' ? 'Homing' : 'Needs homing';
  } else {
    el.status.textContent = `${STATE_LABEL[rail.state] ?? rail.state} at ${Math.round(rail.positionMm)} mm`;
  }
  el.status.dataset.state = !online ? 'offline' : rail.state;

  // --- mode ---
  el.modeStatic.setAttribute('aria-checked', String(isStatic));
  el.modeSweep.setAttribute('aria-checked', String(!isStatic));
  el.modeStatic.disabled = !online;
  el.modeSweep.disabled = !online;
  el.paneStatic.hidden = !isStatic;
  el.paneSweep.hidden = isStatic;

  // --- fault ---
  if (online && rail.fault) {
    el.fault.hidden = false;
    el.faultMessage.textContent = rail.fault.message || 'The rail stopped itself.';
  } else {
    el.fault.hidden = true;
  }
  el.faultClear.disabled = busy;

  // --- track ---
  const pct = (mm) => Math.max(0, Math.min(100, (mm / t) * 100));
  el.trackFan.style.left = `${pct(rail.positionMm)}%`;
  el.trackFan.dataset.moving = String(rail.moving);
  el.trackFan.hidden = !online || !rail.homed;
  if (!isStatic && rail.sweep.maxMm > rail.sweep.minMm) {
    el.trackSweep.hidden = false;
    el.trackSweep.style.left = `${pct(rail.sweep.minMm)}%`;
    el.trackSweep.style.width = `${pct(rail.sweep.maxMm) - pct(rail.sweep.minMm)}%`;
  } else {
    el.trackSweep.hidden = true;
  }

  // --- position mode ---
  el.pos.min = HW.RAIL_SOFT_MARGIN_MM;
  el.pos.max = Math.max(HW.RAIL_SOFT_MARGIN_MM + 1, t - HW.RAIL_SOFT_MARGIN_MM);
  if (dragging !== 'pos' && online && rail.homed && rail.moving) {
    if (Math.abs(Number(el.pos.value) - rail.targetMm) > 2) el.pos.value = rail.targetMm;
  }
  el.posOut.innerHTML = `${Math.round(Number(el.pos.value))} <small>mm</small>`;

  const staticOk = online && rail.homed && rail.canMove && rail.state !== 'fault';
  const picked = Number(el.pos.value);
  el.pos.disabled = !staticOk || busy || rail.moving;
  el.move.disabled = !staticOk || busy || rail.moving || Math.abs(picked - rail.positionMm) < 1;
  el.stop.disabled = !online || busy || !rail.moving;
  el.centre.disabled = !staticOk || busy || rail.moving;
  el.home.disabled = !online || !rail.canMove || rail.state === 'fault' || busy ||
                     rail.state === 'homing';

  if (!online) {
    el.staticNote.textContent = 'The rail is not connected.';
  } else if (rail.state === 'fault') {
    el.staticNote.textContent = 'Clear the fault, then home the rail.';
  } else if (!rail.homed) {
    el.staticNote.textContent = rail.state === 'homing'
      ? 'Finding the home switch.'
      : 'Press Home so the rail knows where it is.';
  } else if (!rail.canMove) {
    el.staticNote.textContent = 'Stop the fan to move the rail.';
  } else if (rail.moving) {
    el.staticNote.textContent = `Moving to ${Math.round(rail.targetMm)} mm. Press Stop to halt.`;
  } else if (Math.abs(picked - rail.positionMm) >= 1) {
    el.staticNote.textContent = `Press Move to go to ${Math.round(picked)} mm.`;
  } else {
    el.staticNote.textContent = 'Pick a position, then press Move.';
  }

  // --- sweep mode ---
  if (dragging !== 'speed' && rail.sweep.speedMms > 0 && rail.sweeping) {
    el.speed.value = rail.sweep.speedMms;
  }
  el.spanOut.innerHTML = `${el.span.value}<small>%</small>`;
  el.speedOut.innerHTML = `${el.speed.value} <small>mm/s</small>`;

  const sweepOk = online && rail.homed && rail.state !== 'fault';
  el.span.disabled = !sweepOk || busy;
  el.speed.disabled = !sweepOk || busy;
  el.sweepStart.disabled = !sweepOk || busy || rail.sweeping;
  el.sweepStop.disabled = !online || busy || !rail.sweeping;

  if (!online) {
    el.sweepNote.textContent = 'The rail is not connected.';
  } else if (!rail.homed) {
    el.sweepNote.textContent = 'Home the rail in Position mode first.';
  } else if (rail.sweeping) {
    el.sweepNote.textContent = `Sweeping ${Math.round(rail.sweep.minMm)} to ${Math.round(rail.sweep.maxMm)} mm.`;
  } else {
    el.sweepNote.textContent = 'The fan glides side to side while it plays.';
  }
}
