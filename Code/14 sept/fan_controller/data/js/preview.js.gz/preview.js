/*
 * preview.js -- renders a polar frame buffer back onto a canvas.
 *
 * This is the inverse of polar.js, and it is genuinely useful rather than
 * decorative: it shows the image exactly as the LEDs will paint it, including
 * the two things that surprise people about POV displays --
 *
 *   1. Radial pixels fan out. Near the hub the 32 LEDs are packed into a tiny
 *      circle; at the rim each one covers a wide arc. Fine detail near the
 *      centre survives, detail at the edge smears.
 *   2. Everything outside the inscribed circle is simply gone.
 *
 * Seeing that before uploading saves a lot of "why does my logo look like
 * that" at an open day.
 */

import { HW } from './config.js';

/** Precomputed (x,y) -> (angleIndex, radialIndex) map, keyed by canvas size. */
const mapCache = new Map();

function lookupMap(size) {
  const cached = mapCache.get(size);
  if (cached) return cached;

  const radial = HW.LEDS_PER_ARM;
  const angles = HW.ANGULAR_STEPS;
  const inner = HW.INNER_RADIUS_RATIO;

  // -1 marks a pixel outside the disc.
  const map = new Int32Array(size * size).fill(-1);
  const c = (size - 1) / 2;

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const dx = (x - c) / c;
      const dy = (y - c) / c;
      const r = Math.sqrt(dx * dx + dy * dy);
      if (r > 1 || r < inner) continue;

      // Match polar.js: angles advance counter-clockwise, y is flipped.
      let theta = Math.atan2(-dy, dx);
      if (theta < 0) theta += 2 * Math.PI;

      const a = Math.min(angles - 1, Math.floor((theta / (2 * Math.PI)) * angles));
      const frac = (r - inner) / (1 - inner);
      const ri = Math.min(radial - 1, Math.floor(frac * radial));

      map[y * size + x] = (a * radial + ri) * 3;
    }
  }

  mapCache.set(size, map);
  return map;
}

/**
 * Paint one polar frame onto a canvas.
 * @param {HTMLCanvasElement} canvas
 * @param {Uint8Array} frame  radial*angles*3 bytes
 */
export function renderFrame(canvas, frame) {
  const size = canvas.width;
  const ctx = canvas.getContext('2d');
  const map = lookupMap(size);
  const img = ctx.createImageData(size, size);
  const out = img.data;

  for (let i = 0, p = 0; i < map.length; i++, p += 4) {
    const o = map[i];
    if (o < 0) {
      out[p + 3] = 0; // transparent outside the disc
      continue;
    }
    out[p] = frame[o];
    out[p + 1] = frame[o + 1];
    out[p + 2] = frame[o + 2];
    out[p + 3] = 255;
  }

  ctx.clearRect(0, 0, size, size);
  ctx.putImageData(img, 0, 0);
}

/**
 * Play a sequence of polar frames on a canvas at the given fps.
 * Returns a handle with stop(); safe to call on a single-frame sequence.
 */
export function playFrames(canvas, frames, fps) {
  let index = 0;
  let raf = null;
  let last = 0;
  const interval = 1000 / Math.max(1, fps);

  if (frames.length === 1) {
    renderFrame(canvas, frames[0]);
    return { stop() {} };
  }

  function tick(now) {
    if (now - last >= interval) {
      renderFrame(canvas, frames[index]);
      index = (index + 1) % frames.length;
      last = now;
    }
    raf = requestAnimationFrame(tick);
  }
  raf = requestAnimationFrame(tick);

  return {
    stop() {
      if (raf) cancelAnimationFrame(raf);
      raf = null;
    },
  };
}

/**
 * Draw the guide ring that sits behind the preview: the disc outline plus a
 * faint marker at the hub, so the user can see where the centre of their
 * image lands.
 */
export function drawGuides(canvas) {
  const ctx = canvas.getContext('2d');
  const s = canvas.width;
  const c = s / 2;
  ctx.clearRect(0, 0, s, s);
  ctx.strokeStyle = 'rgba(255,255,255,0.14)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.arc(c, c, c - 1, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(c, c, 2, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(255,255,255,0.22)';
  ctx.fill();
}
