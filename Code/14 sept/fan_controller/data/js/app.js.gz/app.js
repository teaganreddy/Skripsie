/*
 * app.js -- wiring.
 *
 * Subscribes to the device, folds telemetry into the store, and re-renders
 * the three panels whenever the store changes. No router, no virtual DOM:
 * one page, three panels, a handful of listeners.
 */

import { subscribe } from './api.js';
import { subscribeState, applyStatus, setConnection, state } from './state.js';
import { initControl, renderControl } from './ui/control.js';
import { initStatus, renderStatus } from './ui/status.js';
import { initContent, renderContent, refreshLibrary, onRotorProgress } from './ui/content.js';
import { initRail, renderRail } from './ui/rail.js';

const toastEl = document.getElementById('toast');

function renderToast() {
  const t = state.toast;
  if (!t) {
    toastEl.hidden = true;
    return;
  }
  toastEl.hidden = false;
  toastEl.dataset.kind = t.kind;
  toastEl.textContent = t.message;
}

function boot() {
  initControl();
  initStatus();
  initContent();
  initRail();

  subscribeState(() => {
    renderControl();
    renderStatus();
    renderRail();
    renderContent();
    renderToast();
  });

  subscribe({
    onStatus: (payload) => applyStatus(payload),
    onConnection: (online, detail) => {
      setConnection(online, detail);
      // Re-pull the library on every reconnect: the device may have been
      // power-cycled, or another phone may have uploaded something.
      if (online) refreshLibrary();
    },
    onRotorProgress,
  });

  // The connection pill starts as "Connecting…" rather than "Offline" so a
  // normal first load doesn't flash a scary red state.
  const label = document.getElementById('conn-label');
  const pill = document.getElementById('conn');
  subscribeState(() => {
    const online = state.connection.online;
    pill.dataset.online = String(online);
    label.textContent = online ? 'Connected' : state.connection.detail || 'Not connected';
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', boot, { once: true });
} else {
  boot();
}
