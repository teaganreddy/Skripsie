/*
 * config.js -- hardware + protocol constants.
 *
 * Everything here describes the physical fan. If you change the LED strip,
 * the motor, or the angular resolution, this is the only file you touch on
 * the frontend side (the firmware has to agree, obviously).
 */

export const HW = {
  /* --- Display geometry -------------------------------------------------
   * One continuous APA102 strip laid across the full diameter of the rotor,
   * so the middle of the strip is the hub and each half is an arm. No dead
   * radius at the centre. Because the two arms sit 180 deg apart, a
   * half-revolution paints the whole disc, so refresh = 2 x (RPM / 60).
   *
   * >>> THESE MATCH THE STRIP THAT IS ACTUALLY BUILT: 36 LEDs, 18 per arm.
   *
   * The design target is 64 / 32, and these were set to that until the rotor
   * hardware was measured. Generating content at the real radial resolution
   * rather than resampling 32 -> 18 on the device is both simpler and much
   * cheaper on the wire:
   *
   *      one frame          17 280 B  ->   9 720 B
   *      64-frame animation  1080 KB  ->   608 KB
   *      push at ~45 KB/s        24 s  ->     14 s
   *
   * These must stay in step with LEDS_TOTAL / LEDS_PER_ARM in
   * rotor_controller/src/config.h. Change both, then `npm run presets` and
   * `npm run build` -- presets are regenerated from source, so going back to
   * 64 / 32 later is one command.
   */
  LEDS_TOTAL: 36,
  LEDS_PER_ARM: 18, // == radial resolution of the image
  ARMS: 2,

  /* Angular sectors sampled around the full 360 deg. Each arm must clock out
   * a fresh column every (360 / ANGULAR_STEPS) degrees.
   *
   * Timing budget at RPM_MAX:
   *   700 rpm = 11.67 rev/s -> 180 sectors = 2100 columns/s = 476 us each.
   *   SK9822 frame for 64 LEDs = 4 + 64*4 + 4 = 264 bytes = 2112 bits,
   *   which at a 10 MHz SPI clock takes ~211 us. Roughly 2x headroom.
   *
   * Raising this to 256 still fits (334 us budget) but leaves little slack
   * for the firmware's own work, so 180 (2 deg) is the default.
   */
  ANGULAR_STEPS: 180,

  /* Physical radius of one arm, millimetres. Used only for labelling the UI --
   * the maths is all in normalised radius. */
  ARM_RADIUS_MM: 222,

  /* Fraction of the arm nearest the hub that carries no usable image.
   * Zero here because the strip runs continuously through the centre. */
  INNER_RADIUS_RATIO: 0,

  /* --- Motor ------------------------------------------------------------
   * These MUST stay in step with RPM_MIN_ALLOWED / RPM_MAX_ALLOWED in
   * fan_controller/src/config.h. The firmware clamps every requested speed to
   * its own band regardless of what this slider offers, so a slider offering
   * speeds the firmware clamps would show a readout that never reaches its
   * setpoint.
   *
   * Raised to the 600-700 rpm design target on 2026-08-18 (firmware was
   * 60-250 until then). The electrical case is worked through in the firmware
   * config.h next to RPM_MAX_ALLOWED; the short version is that back-EMF rises
   * with speed, so the driver actually passes LESS current at 700 rpm than at
   * standstill, and the worst case did not move.
   *
   * RPM_STEP is 50 and RPM_MIN is 0, so the slider offers exactly
   * 0, 50, 100 ... 700 -- fifteen detents rather than a continuous sweep. That
   * is deliberate: it makes a speed reproducible when someone reports what
   * they saw at it, and it keeps the bring-up steps in BRINGUP.md and the
   * positions on this slider the same thing.
   *
   * ZERO IS A REAL POSITION, not a clamped-away one. The firmware treats a
   * speed request of 0 as a controlled power-down at the usual 60 rpm/s -- NOT
   * as the E-STOP, which coasts. Moving the slider back up afterwards sets the
   * target but does NOT restart the motor; that still takes the power button.
   */
  RPM_MIN: 0,
  RPM_MAX: 700,
  RPM_DEFAULT: 150,
  RPM_STEP: 50,
  /* Below this the persistence-of-vision effect breaks down and the user
   * will see visible flicker rather than a solid image. The slider marks
   * this band so a walk-up user knows where the picture actually forms. */
  RPM_POV_MIN: 600,
  RPM_POV_MAX: 750,

  /* --- Animation -------------------------------------------------------- */
  FPS_MIN: 10,
  FPS_MAX: 12,
  FPS_DEFAULT: 12,
  /* Hard ceiling on frames per upload. 64 frames x 17.3 KB = ~1.1 MB, which
   * fits the rotor's PSRAM but takes a while to push over ESP-NOW. */
  MAX_FRAMES: 64,

  /* --- Linear rail -------------------------------------------------------
   * MUST stay in step with rail_controller/src/config.h and the RAIL_*
   * constants in fan_controller/src/config.h. The rail reports its own
   * travel in every status packet and that overrides RAIL_TRAVEL_MM here;
   * this is only the figure shown before the rail has been heard from. */
  RAIL_TRAVEL_MM: 500,
  RAIL_STEPS_PER_MM: 40,     // GT2 20T, 1/8 step: 1600 steps per 40 mm
  RAIL_SOFT_MARGIN_MM: 5,    // targets are clamped this far inside the switches
  RAIL_SPEED_MIN_MMS: 5,
  RAIL_SPEED_MAX_MMS: 60,    // hard cap in the firmware too
  RAIL_SPEED_DEFAULT_MMS: 25,
  RAIL_DWELL_DEFAULT_MS: 1000,

  /* --- Upload limits ---------------------------------------------------- */
  ACCEPTED_TYPES: ['image/jpeg', 'image/png', 'image/gif'],
  /* Source file cap before conversion. The converted payload is always a
   * fixed size regardless of source, but we refuse silly inputs so the
   * browser doesn't sit there decoding a 40 MP photo. */
  MAX_SOURCE_BYTES: 12 * 1024 * 1024,
};

/* Bytes on the wire for a single converted frame. */
export const FRAME_BYTES = HW.LEDS_PER_ARM * HW.ANGULAR_STEPS * 3; // 9720

/* --- Image processing defaults ------------------------------------------
 * Gamma: source images are sRGB-encoded, but LED PWM is linear in duty
 * cycle. Without decoding, midtones come out washed out and pale on the
 * strip. 2.2 is the standard sRGB approximation.
 */
export const IMAGE_DEFAULTS = {
  gamma: 2.2,
  brightness: 1.0,
  fit: 'cover', // 'cover' fills the disc and crops the corners; 'contain' letterboxes
  rotationDeg: 0,
  mirror: false,
};

/* --- Networking ---------------------------------------------------------
 * In production the page is served *by* the ESP32-C6, so a relative base
 * URL is correct and requests go back to whichever host served the page
 * (fan.local, 192.168.4.1, whatever). During development the page is served
 * by the mock server on the dev machine, which also answers /api/*, so the
 * same relative base works there too.
 *
 * Override with ?api=http://192.168.4.1 to point a locally-served page at a
 * real device -- handy for debugging the firmware without reflashing the UI.
 */
export function apiBase() {
  const override = new URLSearchParams(location.search).get('api');
  return override ? override.replace(/\/$/, '') : '';
}

/* Status is pushed over Server-Sent Events. If the stream drops (rotor
 * reboots, WiFi hiccups) we fall back to polling at this interval until it
 * reconnects. */
export const SSE_PATH = '/api/events';
export const POLL_MS = 1500;
export const RECONNECT_MS = 3000;
